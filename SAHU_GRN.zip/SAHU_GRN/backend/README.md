# SAHU - Intelligent Document Processing (IDP) Platform

SAHU is a powerful, production-ready Intelligent Document Processing (IDP) application designed to extract structured high-fidelity data from localized business documents like Invoices and Aadhaar cards using state-of-the-art Vision Language Models (VLM) and OCR technology.

## 🚀 Vision

SAHU simplifies document workflows by providing a multi-tenant, role-based platform that handles everything from upload to verification, ensuring data integrity and accessibility across distributed company locations.

## ✨ Core Features

- **Multi-Tenancy & RBAC**: Advanced access control where users are assigned to specific Companies and Locations.
- **Smart Extraction**: 
  - **Invoices**: Automated extraction of Vendor details, Line items, Tax info, and PO numbers.
  - **Aadhaar Cards**: Secure extraction of Identity details with specialized VLM prompts.
- **Processing Pipeline**: Robust background processing using a dedicated VLM/OCR engine.
- **Interactive Dashboard**: Control center for tracking "who, where, and when" for every document.
- **Global Search**: Search through documents by filename, status, or the uploading user.
- **Data Persistence**: Scalable PostgreSQL database managed via SQLModel.

## 🛠️ Technology Stack

- **Backend**: FastAPI (Python 3.12+)
- **ORM**: SQLModel (SQLAlchemy-based)
- **Database**: PostgreSQL
- **Infrastructure**: Docker & Docker Compose
- **Design**: Vanilla CSS with modern aesthetics (Tailwind-like layouts)
- **AI/ML**: Seamless integration with remote Vision Language Models and OCR engines.

## 📦 Getting Started

### 1. Prerequisites

- [Docker Desktop](https://www.docker.com/products/docker-desktop/) installed and running.
- Python 3.12 (optional, for local script execution).

### 2. Configure Environment

Create a `.env` file in the root directory (refer to `.env.example` if available):

```env
# Database 
POSTGRES_USER=
POSTGRES_PASSWORD=
POSTGRES_DB=
DATABASE_URL=

# OCR/VLM Engine
OCR_ENGINE_URL=

# Security
SECRET_KEY=
```

### 3. Start the Platform

Run the following command to start the database and the backend application:

```bash
docker compose up -d --build
```

The application will be available at:
- **Frontend/Dashboard**: [http://localhost:8002](http://localhost:8002)
- **Interactive API Docs**: [http://localhost:8001/docs](http://localhost:8001/docs)

### 4. Seed Initial Data

To set up your initial users, companies, and locations, run the seeding script:

```bash
# Ensure dependencies are installed
pip install sqlmodel pydantic passlib[argon2] python-dotenv

# Run the seeding script
python seed_data/seed_users.py
```

*Note: The script will prompt you for a superuser password if not configured in `users_seed.json`.*

## 📂 Project Structure

```
SAHU/
├── app/                    # Core Application Logic
│   ├── api/routes         # API Endpoints (Invoices, Aadhaar, Auth)
│   ├── db/                # Database Models & Schemas
│   ├── templates/         # UI Components (Invoices, Aadhaar, Login)
│   ├── main.py            # FastAPI Entry Point
├── seed_data/             # Initial setup scripts and JSON
├── docker/                # Docker configuration files
├── uploads/               # Processed documents storage
├── requirements.txt       # Python dependencies
└── docker-compose.yml     # Infrastructure orchestration
```

## 🔒 Security & Access Control

SAHU implements a strict "Workspace" selection flow. Upon login, users must select their assigned **Company** and **Location** before accessing any sensitive data. This ensures that every document processed is correctly tagged and isolated within its respective operational unit.

## 📄 License

Internal Project - All rights reserved by SAHU.
