import os
import json
from sqlalchemy import create_engine, text
from passlib.context import CryptContext

# --- SEEDING CONFIGURATION ---
# Replace this URL with your actual database connection string.
# The engine will automatically detect if it is SQLite, PostgreSQL, MySQL, etc.
DATABASE_URL = "postgresql://postgres:Tiger9River4Cloud7Stone@localhost:5434/SahuDB"

# --- PASSWORD HASHING ---
# Ensure the same algorithm as the main app is used for hashing
pwd_context = CryptContext(schemes=["pbkdf2_sha256"], deprecated="auto")

def get_password_hash(password: str) -> str:
    return pwd_context.hash(password)

def seed_users():
    """Independent seeding script using raw SQL queries for absolute control."""
    
    print(f"Connecting to database via URL: {DATABASE_URL}")
    engine = create_engine(DATABASE_URL)
    
    # Load JSON Data
    json_path = os.path.join(os.path.dirname(__file__), "users_seed.json")
    if not os.path.exists(json_path):
        print(f"Error: {json_path} not found. Ensure users_seed.json is in the same directory.")
        return

    with open(json_path, "r") as f:
        seed_data = json.load(f)

    with engine.connect() as conn:
        # Start a transaction
        transaction = conn.begin()
        try:
            # 1. Seed Admins
            admins = seed_data.get("admins", [])
            for admin in admins:
                username = admin.get("username")
                password = admin.get("password")
                full_name = admin.get("full_name", "Admin")

                # Check if admin already exists
                check_stmt = text("SELECT id FROM users WHERE username = :u")
                existing = conn.execute(check_stmt, {"u": username}).fetchone()
                
                if not existing:
                    print(f"Adding admin: {username}")
                    hashed = get_password_hash(password)
                    ins_stmt = text("""
                        INSERT INTO users (username, password_hash, full_name, role)
                        VALUES (:u, :p, :f, 'admin')
                    """)
                    conn.execute(ins_stmt, {"u": username, "p": hashed, "f": full_name})

            # 2. Seed Mappings (Company, Location, User)
            mappings = seed_data.get("mappings", [])
            for entry in mappings:
                c_name = entry.get("company")
                l_name = entry.get("location")
                u_name = entry.get("user")
                u_pass = entry.get("password", "Pass123")

                # --- Get or create Company ---
                find_c = text("SELECT id FROM companies WHERE name = :n")
                row_c = conn.execute(find_c, {"n": c_name}).fetchone()
                if not row_c:
                    conn.execute(text("INSERT INTO companies (name) VALUES (:n)"), {"n": c_name})
                    row_c = conn.execute(find_c, {"n": c_name}).fetchone()
                company_id = row_c[0]

                # --- Get or create Location ---
                find_l = text("SELECT id FROM locations WHERE name = :n")
                row_l = conn.execute(find_l, {"n": l_name}).fetchone()
                if not row_l:
                    conn.execute(text("INSERT INTO locations (name) VALUES (:n)"), {"n": l_name})
                    row_l = conn.execute(find_l, {"n": l_name}).fetchone()
                location_id = row_l[0]

                # --- Get or create User ---
                find_u = text("SELECT id FROM users WHERE username = :u")
                row_u = conn.execute(find_u, {"u": u_name}).fetchone()
                if not row_u:
                    print(f"Adding user: {u_name}")
                    hashed = get_password_hash(u_pass)
                    conn.execute(text("""
                        INSERT INTO users (username, password_hash, full_name, role)
                        VALUES (:u, :p, :f, 'user')
                    """), {"u": u_name, "p": hashed, "f": u_name})
                    row_u = conn.execute(find_u, {"u": u_name}).fetchone()
                user_id = row_u[0]

                # --- Create Access Mapping if not exists ---
                find_acc = text("""
                    SELECT id FROM user_access 
                    WHERE user_id = :uid AND company_id = :cid AND location_id = :lid
                """)
                row_acc = conn.execute(find_acc, {
                    "uid": user_id, "cid": company_id, "lid": location_id
                }).fetchone()
                
                if not row_acc:
                    conn.execute(text("""
                        INSERT INTO user_access (user_id, company_id, location_id)
                        VALUES (:uid, :cid, :lid)
                    """), {"uid": user_id, "cid": company_id, "lid": location_id})

            transaction.commit()
            print("Database seeding completed.")
        except Exception as e:
            transaction.rollback()
            print(f"Error during seeding: {e}")

if __name__ == "__main__":
    seed_users()
