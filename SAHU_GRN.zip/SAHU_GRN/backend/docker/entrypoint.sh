#!/bin/bash
set -e

# Execute the command
cd /app
exec "$@"