import os
from typing import Optional
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env", env_ignore_empty=True, extra="ignore"
    )
    
    API_V1_STR: str = "/api/v1"
    PROJECT_NAME: str = "SAHU IDP"

    # Database settings 
    POSTGRES_USER: str
    POSTGRES_PASSWORD: str 
    POSTGRES_DB: str 
    DATABASE_URL: str

    # Upload settings
    UPLOAD_DIR: str = "./uploads"
    ARTIFACTS_DIR: str = "./artifacts"
    MAX_UPLOAD_SIZE: int = 25 * 1024 * 1024 

    # OCR Engine settings
    OCR_ENGINE_URL: str
    OCR_ENGINE_SERVICE_TOKEN: str

    # Authentication (JWT)
    SECRET_KEY: str
    ALGORITHM: str
    ACCESS_TOKEN_EXPIRE_MINUTES: int


settings = Settings()
