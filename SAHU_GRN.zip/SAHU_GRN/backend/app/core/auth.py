from datetime import datetime, timedelta
from typing import Optional, Dict, Any

import jwt
from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from pydantic import BaseModel

from app.core.config import settings
from sqlmodel import Session, select
from app.db.session import engine
from app.db.db_models import User
from passlib.context import CryptContext

pwd_context = CryptContext(schemes=["pbkdf2_sha256"], deprecated="auto")

# OAuth2 scheme for token authentication
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/v1/auth/login")


from app.schemas.auth_models import Token, TokenData

# JWT functions
def create_access_token(data: Dict[str, Any], expires_delta: Optional[timedelta] = None) -> str:
    """
    Create a JWT access token with expiration
    """
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)

    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, settings.SECRET_KEY, algorithm=settings.ALGORITHM)
    return encoded_jwt


def verify_token(token: str) -> TokenData:
    """
    Verify a JWT token and return the token data
    """
    try:
        payload = jwt.decode(token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM])
        username: str = payload.get("sub")
        if username is None:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid authentication credentials",
                headers={"WWW-Authenticate": "Bearer"},
            )
        return TokenData(username=username)
    except jwt.PyJWTError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid authentication credentials",
            headers={"WWW-Authenticate": "Bearer"},
        )


# Auth dependencies
async def get_current_user(token: str = Depends(oauth2_scheme)) -> User:
    """
    Dependency to get the current authenticated user from token
    """
    token_data = verify_token(token)
    with Session(engine) as session:
        user = session.exec(select(User).where(User.username == token_data.username)).first()
        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="User not found",
            )
        return user


# Verify username and password
def authenticate_user(username: str, password: str) -> Optional[User]:
    """
    Authenticate a user against the User table
    """
    with Session(engine) as session:
        user = session.exec(select(User).where(User.username == username)).first()
        if user and pwd_context.verify(password, user.password_hash):
            return user
        return None

def get_password_hash(password: str) -> str:
    return pwd_context.hash(password)

def verify_access(db: Session, user: User, company_id: int, location_id: int) -> bool:
    """Check if the user has access to the specified company and location."""
    if user.role == "admin":
        return True
    
    from app.db.db_models import UserAccess
    stmt = select(UserAccess).where(
        UserAccess.user_id == user.id,
        UserAccess.company_id == company_id,
        UserAccess.location_id == location_id
    )
    result = db.exec(stmt).first()
    return result is not None