from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import RedirectResponse
import jwt
from app.core.config import settings


class AuthMiddleware(BaseHTTPMiddleware):
    """
    Middleware to protect routes that should require authentication.
    Redirects to login page if not authenticated.
    """

    async def dispatch(self, request: Request, call_next):
        # Paths that don't require authentication
        open_paths = ["/login", "/", "/api/v1/auth/login"]
        static_path = "/static/"

        # Allow access to public routes
        if request.url.path in open_paths or request.url.path.startswith(static_path):
            return await call_next(request)

        # For API routes, let the OAuth2 dependency handle authentication
        if request.url.path.startswith("/api/v1/") and request.url.path != "/api/v1/auth/login":
            return await call_next(request)

        # Check for authentication token in cookie
        token = request.cookies.get("access_token")

        # Verify token
        if token:
            try:
                jwt.decode(token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM])
                # Token is valid, continue to route
                return await call_next(request)
            except jwt.PyJWTError:
                # Token is invalid, redirect to login
                pass

        # No valid token, redirect to login page
        return RedirectResponse(url="/login")