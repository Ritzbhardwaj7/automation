from contextlib import asynccontextmanager

from fastapi import FastAPI, Request, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from app.api.routes import auth, invoices, aadhaars, admin  # Import auth router
from app.core.auth import get_current_user  # Import auth dependency
from app.core.config import settings
from app.core.middleware import AuthMiddleware  # Import middleware
from app.db import db_models  # Ensure models are registered
from app.db.session import engine
from sqlmodel import SQLModel
from app.db.init_db import init_db

# Create a lifespan handler that ensures tables exist
@asynccontextmanager
async def lifespan(app: FastAPI):
    SQLModel.metadata.create_all(engine)
    try:
        init_db()
    except Exception as e:
        print(f"Error initializing DB: {e}")
    yield


# Initialize FastAPI app with lifespan
app = FastAPI(title=settings.PROJECT_NAME, lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # For development - restrict in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Add auth middleware to protect routes
app.add_middleware(AuthMiddleware)

# Mount static files
app.mount("/static", StaticFiles(directory="app/static"), name="static")

# Include routers
app.include_router(
    auth.router,
    prefix=f"{settings.API_V1_STR}/auth",
    tags=["auth"]
)

app.include_router(
    invoices.router,
    prefix=f"{settings.API_V1_STR}/invoices",
    tags=["invoice"],
    dependencies=[Depends(get_current_user)]
)

app.include_router(
    aadhaars.router,
    prefix=f"{settings.API_V1_STR}/aadhaars",
    tags=["aadhaar"],
    dependencies=[Depends(get_current_user)]
)

app.include_router(
    admin.router,
    prefix=f"{settings.API_V1_STR}/admin",
    tags=["admin"],
    dependencies=[Depends(get_current_user)]
)

# Configure templates
templates = Jinja2Templates(directory="app/templates")


# Login page (entry point)
@app.get("/", tags=["pages"])
async def root(request: Request):
    return RedirectResponse(url="/invoices")


@app.get("/login", tags=["pages"], name="login")
async def login_page(request: Request):
    return templates.TemplateResponse("login.html", {"request": request, "hide_header": True})

@app.get("/select-access", tags=["pages"], name="select_access")
async def select_access_page(request: Request):
    return templates.TemplateResponse("select_access.html", {"request": request, "hide_header": True})


@app.get('/health/up')
def health():
    return {"status": "ok"}
@app.get("/invoices", tags=["pages"], name="invoice")
async def invoice_page(request: Request):
    return templates.TemplateResponse("invoices.html", {"request": request, "active_page": "invoices"})


@app.get("/invoices/{log_id}")
async def invoice_detail_page(request: Request, log_id: str):
    """Render the invoice detail page"""
    return templates.TemplateResponse("invoice_details.html", {
        "request": request,
        "active_page": "invoices",
        "log_id": log_id
    })
@app.get("/user-control", tags=["pages"], name="user_control")
async def user_control_page(request: Request):
    return templates.TemplateResponse("user_control.html", {"request": request, "active_page": "user_control"})

@app.get("/aadhaars", tags=["pages"], name="aadhaar")
async def aadhaar_page(request: Request):
    return templates.TemplateResponse("aadhaars.html", {"request": request, "active_page": "aadhaars"})


@app.get("/aadhaars/{log_id}", name="aadhaar_detail")
async def aadhaar_detail_page(request: Request, log_id: str):
    """Render the aadhaar detail page"""
    return templates.TemplateResponse("aadhaar_details.html", {
        "request": request,
        "active_page": "aadhaars",
        "log_id": log_id
    })
