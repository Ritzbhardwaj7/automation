import base64
import os
import tempfile
import asyncio
import httpx
import json
import logging
from typing import Any, Tuple, List, Optional, Dict
import aiofiles
import aioshutil as async_shutil
from pdf2image import convert_from_path
from pydantic import BaseModel, Field
from io import BytesIO

from app.db.db_models import Aadhaar, Invoice
from app.core.config import settings
from app.schemas.extraction_models import (
    AadhaarKeyValuePair, AadhaarExtractionResult, AadhaarPageExtraction,
    InvoiceKeyValuePair, InvoiceTerm, InvoiceTable, InvoiceExtractionResult, InvoicePageExtraction
)

logger = logging.getLogger(__name__)

# --- Unified Extraction Service ---
class ExtractionService:
    """Unified Extraction Service using Qwen3-VL OCR engine."""

    def __init__(self):
        self.base_url = settings.OCR_ENGINE_URL.rstrip('/')
        self.secret_key = settings.OCR_ENGINE_SERVICE_TOKEN


    async def _call_qwen_ocr(self, b64_image: str, doc_type: str = "default") -> Dict[str, Any]:
        """Call the OCR Engine's /generate endpoint."""
        # The secret_key from settings is used as the SERVICE_TOKEN
        headers = {"Authorization": f"Bearer {self.secret_key}"}
        
        payload = {
            "doc_type": doc_type,
            "image": b64_image
        }

        async with httpx.AsyncClient(timeout=120.0) as client:
            url = f"{self.base_url}/generate"
            logger.info(f"Calling Qwen OCR engine at {url} for type {doc_type}")
            
            try:
                # payload is JSON-serialized automatically by httpx when using the json argument
                response = await client.post(url, headers=headers, json=payload)
                response.raise_for_status()
                # The API returns {"data": { ... }}
                full_json = response.json()
                return full_json.get("data", {})
            except httpx.HTTPError as e:
                logger.error(f"Error calling Qwen OCR engine: {e}")
                raise Exception(f"Qwen OCR engine call failed: {str(e)}")

    def _parse_json_result(self, data: Any) -> dict:
        """Helper to ensure the input is a dictionary or parsed from a JSON string."""
        if isinstance(data, dict):
            return data
        if not isinstance(data, str):
            return {}
            
        text = data.strip()
        # Handle cases where model wraps JSON in markdown blocks
        if text.startswith("```"):
            lines = text.split("\n")
            if len(lines) > 2:
                if lines[0].startswith("```json") or lines[0].startswith("```"):
                    text = "\n".join(lines[1:-1])
        try:
            return json.loads(text)
        except:
            return {}

    # --- Aadhaar Extraction ---
    async def process_aadhaar(
        self,
        file_bytes: bytes,
        filename: str,
        aadhaar_id: str
    ) -> Tuple[Aadhaar, List[AadhaarPageExtraction], List[str]]:
        """Process an Aadhaar card document (Image or PDF)."""
        is_pdf = filename.lower().endswith(".pdf")
        b64_images = []
        page_extractions = []
        last_ocr_result = None

        if not is_pdf:
            b64_image = base64.b64encode(file_bytes).decode("utf-8")
            b64_images.append(b64_image)
            
            # The new API returns the extracted data directly
            extraction_data = await self._call_qwen_ocr(b64_image, doc_type="aadhaar")
            last_ocr_result = {"data": extraction_data} # Store in a consistent format
            
            parsed_data = self._parse_json_result(extraction_data)
            
            page_data = AadhaarPageExtraction(
                page_number=1,
                key_value_pairs=AadhaarExtractionResult.model_validate(parsed_data).key_value_pairs
            )
            page_extractions.append(page_data)
        else:
            temp_dir = tempfile.mkdtemp()
            pdf_path = os.path.join(temp_dir, filename)
            async with aiofiles.open(pdf_path, "wb") as f:
                await f.write(file_bytes)

            try:
                images = await asyncio.to_thread(
                    convert_from_path, pdf_path=pdf_path, dpi=200, fmt="png"
                )

                for idx, img in enumerate(images):
                    buf = BytesIO()
                    img.save(buf, format="PNG")
                    img_bytes = buf.getvalue()
                    b64 = base64.b64encode(img_bytes).decode("utf-8")
                    b64_images.append(b64)

                    extraction_data = await self._call_qwen_ocr(b64, doc_type="aadhaar")
                    last_ocr_result = {"data": extraction_data}
                    
                    parsed_data = self._parse_json_result(extraction_data)
                    
                    page_data = AadhaarPageExtraction(
                        page_number=idx + 1,
                        key_value_pairs=AadhaarExtractionResult.model_validate(parsed_data).key_value_pairs
                    )
                    page_extractions.append(page_data)
            finally:
                if os.path.exists(temp_dir):
                    await async_shutil.rmtree(temp_dir)

        final_extraction_json = {
            "page-wise-data": [p.model_dump(by_alias=True) for p in page_extractions]
        }

        aadhaar = Aadhaar(
            aadhaar_id=aadhaar_id,
            title=filename.split(".")[0],
            extension=filename.split(".")[-1] if not is_pdf else "pdf",
            original_filename=filename,
            file_hash=str(hash(file_bytes)),
            page_count=len(b64_images),
            extraction_json=final_extraction_json,
            ocr_result=last_ocr_result,
            status="uploaded",
        )

        return aadhaar, page_extractions, b64_images

    # --- Invoice Extraction ---
    async def process_invoice(
        self,
        file_bytes: bytes,
        filename: str,
        invoice_id: str
    ) -> Tuple[Invoice, List[InvoicePageExtraction], List[str]]:
        """Process an invoice document (Image or PDF)."""
        is_pdf = filename.lower().endswith(".pdf")
        b64_images = []
        page_extractions = []
        last_ocr_result = None

        if not is_pdf:
            b64_image = base64.b64encode(file_bytes).decode("utf-8")
            b64_images.append(b64_image)
            
            extraction_data = await self._call_qwen_ocr(b64_image, doc_type="invoice")
            last_ocr_result = {"data": extraction_data}
            
            parsed_data = self._parse_json_result(extraction_data)
            ext_res = InvoiceExtractionResult.model_validate(parsed_data)
            
            page_data = InvoicePageExtraction(
                page_number=1,
                key_value_pairs=ext_res.key_value_pairs,
                tables=ext_res.tables,
                terms=ext_res.terms
            )
            page_extractions.append(page_data)
        else:
            temp_dir = tempfile.mkdtemp()
            pdf_path = os.path.join(temp_dir, filename)
            async with aiofiles.open(pdf_path, "wb") as f:
                await f.write(file_bytes)

            try:
                images = await asyncio.to_thread(
                    convert_from_path, pdf_path=pdf_path, dpi=200, fmt="png"
                )

                for idx, img in enumerate(images):
                    buf = BytesIO()
                    img.save(buf, format="PNG")
                    img_bytes = buf.getvalue()
                    b64 = base64.b64encode(img_bytes).decode("utf-8")
                    b64_images.append(b64)

                    extraction_data = await self._call_qwen_ocr(b64, doc_type="invoice")
                    last_ocr_result = {"data": extraction_data}
                    
                    parsed_data = self._parse_json_result(extraction_data)
                    ext_res = InvoiceExtractionResult.model_validate(parsed_data)
                    
                    page_data = InvoicePageExtraction(
                        page_number=idx + 1,
                        key_value_pairs=ext_res.key_value_pairs,
                        tables=ext_res.tables,
                        terms=ext_res.terms
                    )
                    page_extractions.append(page_data)
            finally:
                if os.path.exists(temp_dir):
                    await async_shutil.rmtree(temp_dir)

        final_extraction_json = {
            "page-wise-data": [p.model_dump(by_alias=True) for p in page_extractions]
        }

        invoice = Invoice(
            invoice_id=invoice_id,
            title=filename.split(".")[0],
            extension=filename.split(".")[-1] if not is_pdf else "pdf",
            original_filename=filename,
            file_hash=str(hash(file_bytes)),
            page_count=len(b64_images),
            extraction_json=final_extraction_json,
            ocr_result=last_ocr_result,
            status="uploaded",
        )

        return invoice, page_extractions, b64_images

    async def summarize_from_extraction(
        self,
        extraction_json: dict,
        prompt: Optional[str] = None
    ) -> Tuple[str, str]:
        """Produce a basic summary from structured JSON when OpenAI is not available."""
        summary_parts = []
        if extraction_json.get("key-value-pairs") or extraction_json.get("page-wise-data"):
            summary_parts.append("Key info extracted locally.")
        if extraction_json.get("tables"):
            summary_parts.append(f"Found {len(extraction_json['tables'])} tables.")
        
        summary_text = " ".join(summary_parts) or "Summary currently unavailable via local engine for pure JSON input."
        if prompt:
            summary_text += f"\n\n(Prompt ignored as local summary engine is basic: {prompt})"
            
        return (summary_text, "local-stub")

    async def generate_summary_from_base64(
        self,
        b64_image: str,
        mime: str = "image/png",
        prompt: Optional[str] = None,
    ) -> Tuple[str, str]:
        """Use Qwen3-VL for summarization."""
        result = await self._call_qwen_ocr(b64_image, doc_type="summary")
        summary_text = str(result)
        return (summary_text, "qwen-vlm-image")

    async def process_invoice_direct(
        self,
        file_bytes: bytes,
        filename: str,
    ) -> InvoiceExtractionResult:
        """Process a single-page invoice image directly without DB."""
        b64_image = base64.b64encode(file_bytes).decode("utf-8")
        extraction_data = await self._call_qwen_ocr(b64_image, doc_type="invoice")
        parsed_data = self._parse_json_result(extraction_data)
        return InvoiceExtractionResult.model_validate(parsed_data)
