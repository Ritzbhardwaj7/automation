from sqlmodel import SQLModel
from app.db.session import engine
from app.db import db_models # Ensure models are loaded

def init_db():
    """Create all tables in the database."""
    print("Creating database tables if they don't exist...")
    SQLModel.metadata.create_all(engine)
    print("Database initialization complete.")

if __name__ == "__main__":
    init_db()
