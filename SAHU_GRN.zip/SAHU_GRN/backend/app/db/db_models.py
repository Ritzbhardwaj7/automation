from datetime import date, datetime
from typing import Optional, List, Dict, Any

from sqlmodel import Field, SQLModel, Column, Date, Integer, ARRAY, String, DateTime, func, JSON


class Invoice(SQLModel, table=True):
    __tablename__ = "invoices"

    # Primary identifier for the invoice document
    invoice_id: str = Field(primary_key=True)

    # Basic metadata (similar to Document, but trimmed)
    title: Optional[str] = Field(default=None, index=True)
    original_filename: Optional[str] = Field(default=None)

    status: Optional[str] = Field(default="uploaded", index=True)
    extension: Optional[str] = Field(default=None)  # "png", "jpg", "jpeg"
    page_count: Optional[int] = Field(default=1, sa_column=Column(Integer))

    # For deduplication
    file_hash: Optional[str] = Field(default=None, index=True)

    # LLM extraction output:
    # stores: {"key-value-pairs": [...], "tables": [...]}
    extraction_json: Optional[Dict[str, Any]] = Field(
        default=None,
        sa_column=Column(JSON)
    )
    
    # Store complete OCR engine result
    ocr_result: Optional[Dict[str, Any]] = Field(
        default=None,
        sa_column=Column(JSON)
    )

    # Tracking
    user_id: Optional[int] = Field(default=None, foreign_key="users.id", index=True)
    company_id: Optional[int] = Field(default=None, foreign_key="companies.id", index=True)
    location_id: Optional[int] = Field(default=None, foreign_key="locations.id", index=True)

    created_at: datetime = Field(
        sa_column=Column(
            DateTime,
            server_default=func.now(),
            nullable=False,
            index=True,
        )
    )


class InvoicePage(SQLModel, table=True):
    __tablename__ = "invoice_pages"

    id: Optional[int] = Field(default=None, primary_key=True)
    invoice_id: str = Field(foreign_key="invoices.invoice_id", index=True)

    page_number: int = Field(index=True)

    # For image-only invoices:
    # content can stay None (or later be used if you OCR)
    content: Optional[str] = Field(default=None)

    # base64-encoded PNG/JPEG for the page image
    base64_image: Optional[str] = Field(default=None)

    created_at: datetime = Field(
        sa_column=Column(
            DateTime,
            server_default=func.now(),
            nullable=False,
            index=True,
        )
    )



class InvoiceSummary(SQLModel, table=True):
    __tablename__ = "invoice_summaries"

    id: Optional[int] = Field(default=None, primary_key=True)

    invoice_id: str = Field(
        foreign_key="invoices.invoice_id",
        index=True,
        nullable=False
    )

    # Text summary generated from the extracted invoice data
    summary_text: Optional[str] = Field(default=None)

    # If you store the prompt used to generate the summary
    generated_prompt: Optional[str] = Field(default=None)

    # Optional stats
    word_count: Optional[int] = Field(default=None, sa_column=Column(Integer))
    confidence_score: Optional[float] = Field(default=None)

    # Type of generation (e.g., "llm", "extractive", "hybrid")
    generation_method: str = Field(default="llm")

    created_at: datetime = Field(
        sa_column=Column(
            DateTime,
            server_default=func.now(),
            nullable=False,
            index=True
        )
    )


class Aadhaar(SQLModel, table=True):
    __tablename__ = "aadhaars"

    aadhaar_id: str = Field(primary_key=True)
    title: Optional[str] = Field(default=None, index=True)
    original_filename: Optional[str] = Field(default=None)
    status: Optional[str] = Field(default="uploaded", index=True)
    extension: Optional[str] = Field(default=None)
    page_count: Optional[int] = Field(default=1, sa_column=Column(Integer))
    file_hash: Optional[str] = Field(default=None, index=True)

    # stores: {"key-value-pairs": [...]}
    extraction_json: Optional[Dict[str, Any]] = Field(
        default=None,
        sa_column=Column(JSON)
    )

    # Store complete OCR engine result
    ocr_result: Optional[Dict[str, Any]] = Field(
        default=None,
        sa_column=Column(JSON)
    )

    # Tracking
    user_id: Optional[int] = Field(default=None, foreign_key="users.id", index=True)
    company_id: Optional[int] = Field(default=None, foreign_key="companies.id", index=True)
    location_id: Optional[int] = Field(default=None, foreign_key="locations.id", index=True)

    created_at: datetime = Field(
        sa_column=Column(
            DateTime,
            server_default=func.now(),
            nullable=False,
            index=True,
        )
    )


class AadhaarPage(SQLModel, table=True):
    __tablename__ = "aadhaar_pages"

    id: Optional[int] = Field(default=None, primary_key=True)
    aadhaar_id: str = Field(foreign_key="aadhaars.aadhaar_id", index=True)
    page_number: int = Field(index=True)
    content: Optional[str] = Field(default=None)
    base64_image: Optional[str] = Field(default=None)
    created_at: datetime = Field(
        sa_column=Column(
            DateTime,
            server_default=func.now(),
            nullable=False,
            index=True,
        )
    )


class User(SQLModel, table=True):
    __tablename__ = "users"
    id: Optional[int] = Field(default=None, primary_key=True)
    username: str = Field(index=True, unique=True)
    password_hash: str
    full_name: Optional[str] = None
    role: str = Field(default="user")  # "admin", "user"


class Company(SQLModel, table=True):
    __tablename__ = "companies"
    id: Optional[int] = Field(default=None, primary_key=True)
    name: str = Field(index=True, unique=True)


class Location(SQLModel, table=True):
    __tablename__ = "locations"
    id: Optional[int] = Field(default=None, primary_key=True)
    name: str = Field(index=True, unique=True)


class UserAccess(SQLModel, table=True):
    __tablename__ = "user_access"
    id: Optional[int] = Field(default=None, primary_key=True)
    user_id: int = Field(foreign_key="users.id", index=True)
    company_id: int = Field(foreign_key="companies.id", index=True)
    location_id: int = Field(foreign_key="locations.id", index=True)
