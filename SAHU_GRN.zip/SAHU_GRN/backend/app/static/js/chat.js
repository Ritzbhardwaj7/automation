// Chat functionality
let chatHistory = [];
let currentConversationId = localStorage.getItem('currentConversationId');
let conversations = [];
let chatHistoryOffset = 0;
let hasMoreChatHistory = false;
let isLoadingChatHistory = false;
let chatScrollContainer = null;
let totalChatCount = 0;

// Configure marked.js for better markdown rendering
if (typeof marked !== 'undefined') {
    // For marked.js v16+, options are passed differently
    marked.use({
        breaks: true,
        gfm: true,
        tables: true,
        smartypants: true
    });
}

// Update chat count display
function updateChatCount(count) {
    totalChatCount = count;
    const chatCountElement = document.getElementById('chat-count');
    if (chatCountElement) {
        if (count === 0) {
            chatCountElement.textContent = 'No conversations';
            chatCountElement.className = 'text-xs text-gray-500 bg-gray-200 px-2 py-1 rounded-full';
        } else {
            chatCountElement.textContent = `${count} conversation${count === 1 ? '' : 's'}`;
            chatCountElement.className = 'text-xs text-gray-600 bg-blue-100 px-2 py-1 rounded-full';
        }
    }
}

// Generate a unique conversation ID
function generateConversationId() {
    return 'conv_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
}

// Create a new conversation
async function createNewConversation(title = null) {
    const conversationId = generateConversationId();

    try {
        const requestData = {
            id: conversationId
        };

        if (title) {
            requestData.title = title;
        }

        const response = await api.fetchWithAuth('/api/v1/crew-chat/conversations', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(requestData)
        });

        if (!response.ok) {
            throw new Error('Failed to create conversation');
        }

        const data = await response.json();
        currentConversationId = data.id;
        localStorage.setItem('currentConversationId', currentConversationId);

        // Clear current chat
        chatHistory = [];
        const messagesContainer = document.getElementById('chat-messages');
        messagesContainer.innerHTML = `
            <div class="text-center text-gray-500 py-8" id="chat-placeholder">
                <div class="text-6xl mb-4">💬</div>
                <h3 class="text-lg font-medium mb-2">Start a Conversation</h3>
                <p>Start a conversation by typing a question below or clicking a sample question.</p>
            </div>
        `;
        updateChatCount(0);

        // Load conversations list
        await loadConversations();

        return conversationId;
    } catch (error) {
        console.error('Error creating conversation:', error);
        // Use a local conversation ID as fallback
        currentConversationId = conversationId;
        localStorage.setItem('currentConversationId', currentConversationId);
        return conversationId;
    }
}

// Load conversations list
async function loadConversations() {
    try {
        const response = await api.fetchWithAuth('/api/v1/crew-chat/conversations');
        if (!response.ok) {
            throw new Error('Failed to load conversations');
        }

        const data = await response.json();
        conversations = data.conversations;
        updateConversationsList();
    } catch (error) {
        console.error('Error loading conversations:', error);
    }
}

// Update conversations list UI
function updateConversationsList() {
    const selector = document.getElementById('conversation-selector');
    if (!selector) return;

    // Clear existing options except the first one
    selector.innerHTML = '<option value="">Select a conversation...</option>';

    // Add conversation options
    conversations.forEach(conv => {
        const option = document.createElement('option');
        option.value = conv.id;
        option.textContent = conv.title || 'Untitled';

        // Mark as selected if this is the current conversation
        if (conv.id === currentConversationId) {
            option.selected = true;
        }

        selector.appendChild(option);
    });

    // If no current conversation but we have conversations, select the first one
    if (!currentConversationId && conversations.length > 0) {
        const firstConv = conversations[0];
        currentConversationId = firstConv.id;
        localStorage.setItem('currentConversationId', currentConversationId);
        selector.value = currentConversationId;
    }

    // Update button visibility
    updateConversationButtons();
}

// Handle conversation selection change
async function onConversationChange(conversationId) {
    if (conversationId && conversationId !== currentConversationId) {
        await switchConversation(conversationId);
    }
}

// Find existing empty conversation or create new one
async function findOrCreateConversation() {
    // First, load the latest conversations
    await loadConversations();

    // If we have a current conversation, check if it's empty first
    if (currentConversationId) {
        const isEmpty = await isConversationEmpty(currentConversationId);
        if (isEmpty) {
            // Current conversation is empty, use it
            return currentConversationId;
        }
    }

    // Check if there's any existing empty conversation
    for (const conv of conversations) {
        // Skip the current conversation (already checked above)
        if (conv.id === currentConversationId) continue;

        // Check if this conversation has any messages
        const isEmpty = await isConversationEmpty(conv.id);
        if (isEmpty) {
            // Use this empty conversation
            currentConversationId = conv.id;
            localStorage.setItem('currentConversationId', currentConversationId);

            // Update the dropdown
            const selector = document.getElementById('conversation-selector');
            if (selector) {
                selector.value = currentConversationId;
            }

            return currentConversationId;
        }
    }

    // No empty conversation found, create a new one
    return await createNewConversation();
}

// Check if a conversation is empty (has no messages)
async function isConversationEmpty(conversationId) {
    try {
        const response = await api.fetchWithAuth(`/api/v1/crew-chat/chat-history?conversation_id=${conversationId}&limit=1&offset=0`);
        if (!response.ok) {
            return false;
        }
        const data = await response.json();
        return data.chat_history.length === 0;
    } catch (error) {
        console.error('Error checking if conversation is empty:', error);
        return false;
    }
}

// Create new conversation manually (from button)
async function createNewConversationManually() {
    // Check if current conversation is already empty
    if (currentConversationId) {
        const isEmpty = await isConversationEmpty(currentConversationId);
        if (isEmpty) {
            // Current conversation is already empty, no need to create new one
            console.log('Current conversation is already empty, not creating new one');

            // Clear the current conversation display to give fresh start feeling
            const messagesContainer = document.getElementById('chat-messages');
            messagesContainer.innerHTML = `
                <div class="text-center text-gray-500 py-8" id="chat-placeholder">
                    <div class="text-6xl mb-4">💬</div>
                    <h3 class="text-lg font-medium mb-2">Start a Conversation</h3>
                    <p>Start a conversation by typing a question below or clicking a sample question.</p>
                </div>
            `;
            // Clear chat history array
            chatHistory = [];
            updateChatCount(0);

            return;
        }
    }

    // Current conversation has messages or no current conversation, create new one
    await createNewConversation();
    // Reload conversations to update the dropdown
    await loadConversations();
}

// Switch to a different conversation
async function switchConversation(conversationId) {
    if (conversationId === currentConversationId) return;

    currentConversationId = conversationId;
    localStorage.setItem('currentConversationId', currentConversationId);
    chatHistory = [];
    chatHistoryOffset = 0;
    hasMoreChatHistory = false;

    // Update the dropdown
    const selector = document.getElementById('conversation-selector');
    if (selector) {
        selector.value = conversationId;
    }

    // Load chat history for this conversation
    await initializeChatHistory();

    // Update button visibility
    updateConversationButtons();
}

// Load chat history from server
async function loadChatHistory(limit = 10, offset = 0) {
    if (isLoadingChatHistory || !currentConversationId) return;

    isLoadingChatHistory = true;

    try {
        const response = await api.fetchWithAuth(`/api/v1/crew-chat/chat-history?conversation_id=${currentConversationId}&limit=${limit}&offset=${offset}`);
        if (!response.ok) {
            throw new Error('Failed to fetch chat history');
        }

        const data = await response.json();
        hasMoreChatHistory = data.has_more;
        chatHistoryOffset = offset + data.chat_history.length;

        // Update total count on first load
        if (offset === 0) {
            updateChatCount(data.total_count);
        }

        return data.chat_history;
    } catch (error) {
        console.error('Error loading chat history:', error);
        return [];
    } finally {
        isLoadingChatHistory = false;
    }
}

// Initialize chat when tab is first activated
async function initializeChat() {
    if (!window.chatInitialized) {
        await loadSampleQuestions();

        // Load conversations list
        await loadConversations();

        // If we have a stored conversation ID, load its history
        if (currentConversationId) {
            await initializeChatHistory();
        } else {
            // Update chat count to show no conversations
            updateChatCount(0);
        }
    }
}

// Initialize chat with recent messages
async function initializeChatHistory() {
    const messagesContainer = document.getElementById('chat-messages');
    chatScrollContainer = messagesContainer.parentElement;

    // Clear existing messages
    messagesContainer.innerHTML = '';
    chatHistory = [];

    // Load recent messages
    const recentMessages = await loadChatHistory(10, 0);

    if (recentMessages && recentMessages.length > 0) {
        // Add messages in chronological order (oldest first)
        recentMessages.reverse().forEach(msg => {
            if (msg.user_message && msg.assistant_message) {
                addHistoryMessageToChat(msg);
            }
        });

        // Scroll to bottom to show most recent messages
        chatScrollContainer.scrollTop = chatScrollContainer.scrollHeight;

        // Set up infinite scroll for loading more history
        setupInfiniteScroll();
    } else {
        // No messages, show placeholder
        messagesContainer.innerHTML = `
            <div class="text-center text-gray-500 py-8" id="chat-placeholder">
                <div class="text-6xl mb-4">💬</div>
                <h3 class="text-lg font-medium mb-2">Start a Conversation</h3>
                <p>Start a conversation by typing a question below or clicking a sample question.</p>
            </div>
        `;
        updateChatCount(0);
    }
}

// Add historical message to chat (different from new messages)
function addHistoryMessageToChat(messageData) {
    // Add user message
    if (messageData.user_message) {
        addMessageToChat('user', messageData.user_message, {
            timestamp: messageData.created_at,
            showTimestamp: true
        });

        // Add to chatHistory for context but avoid duplicates
        if (!chatHistory.some(msg => msg.role === 'user' && msg.content === messageData.user_message)) {
            chatHistory.push({ role: 'user', content: messageData.user_message });
        }
    }

    // Add assistant message
    if (messageData.assistant_message) {
        console.log('Adding historical chat message with metadata:', {
            chatId: messageData.id,
            isFavorite: messageData.is_favorite,
            filePaths: messageData.file_paths
        });

        addMessageToChat('assistant', messageData.assistant_message, {
            timestamp: messageData.created_at,
            showTimestamp: true,
            filePaths: messageData.file_paths,
            chatId: messageData.id,
            isFavorite: messageData.is_favorite
        });

        // Add to chatHistory for context but avoid duplicates
        if (!chatHistory.some(msg => msg.role === 'assistant' && msg.content === messageData.assistant_message)) {
            chatHistory.push({ role: 'assistant', content: messageData.assistant_message });
        }
    }
}

// Set up infinite scroll for loading more chat history
function setupInfiniteScroll() {
    if (!chatScrollContainer) return;

    chatScrollContainer.addEventListener('scroll', async () => {
        // Check if user scrolled to top and there's more history to load
        if (chatScrollContainer.scrollTop === 0 && hasMoreChatHistory && !isLoadingChatHistory) {
            await loadMoreChatHistory();
        }
    });
}

// Load more chat history (for infinite scroll)
async function loadMoreChatHistory() {
    if (!hasMoreChatHistory || isLoadingChatHistory) return;

    // Show loading indicator at the top
    const messagesContainer = document.getElementById('chat-messages');
    const loadingDiv = document.createElement('div');
    loadingDiv.id = 'chat-loading';
    loadingDiv.className = 'text-center py-4 text-gray-500';
    loadingDiv.innerHTML = `
        <div class="flex items-center justify-center space-x-2">
            <div class="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-500"></div>
            <span>Loading more messages...</span>
        </div>
    `;
    messagesContainer.insertBefore(loadingDiv, messagesContainer.firstChild);

    // Remember current scroll position
    const oldScrollHeight = chatScrollContainer.scrollHeight;

    // Load older messages
    const olderMessages = await loadChatHistory(10, chatHistoryOffset);

    // Remove loading indicator
    const loadingIndicator = document.getElementById('chat-loading');
    if (loadingIndicator) {
        loadingIndicator.remove();
    }

    if (olderMessages && olderMessages.length > 0) {
        // Add older messages to the top in reverse chronological order
        olderMessages.reverse().forEach(msg => {
            addHistoryMessageToTop(msg);
        });

        // Maintain scroll position
        const newScrollHeight = chatScrollContainer.scrollHeight;
        chatScrollContainer.scrollTop = newScrollHeight - oldScrollHeight;
    }
}

// Add historical message to top of chat
function addHistoryMessageToTop(messageData) {
    const messagesContainer = document.getElementById('chat-messages');

    // Create container for this conversation pair
    const conversationDiv = document.createElement('div');
    conversationDiv.className = 'space-y-4';

    // Add user message
    if (messageData.user_message) {
        const userMsgDiv = createMessageElement('user', messageData.user_message, {
            timestamp: messageData.created_at,
            showTimestamp: true
        });
        conversationDiv.appendChild(userMsgDiv);
    }

    // Add assistant message
    if (messageData.assistant_message) {
        const assistantMsgDiv = createMessageElement('assistant', messageData.assistant_message, {
            timestamp: messageData.created_at,
            showTimestamp: true,
            filePaths: messageData.file_paths,
            chatId: messageData.id,
            isFavorite: messageData.is_favorite
        });
        conversationDiv.appendChild(assistantMsgDiv);
    }

    // Insert at the beginning
    messagesContainer.insertBefore(conversationDiv, messagesContainer.firstChild);
}

// Clear chat history and start new conversation
async function clearChatHistory() {
    // Create a new conversation
    await createNewConversation();
}

// Copy message content to clipboard
async function copyMessage(messageElement) {
    let textToCopy = '';

    // Try to get the original markdown content first
    const contentDiv = messageElement.querySelector('.message-content');
    if (contentDiv) {
        // Check if we have the original content stored as a data attribute
        const originalContent = contentDiv.getAttribute('data-original-content');
        if (originalContent) {
            textToCopy = originalContent;
        } else {
            // Fall back to text content
            textToCopy = contentDiv.textContent || contentDiv.innerText;
        }
    } else {
        // Fallback to the entire message text
        textToCopy = messageElement.textContent || messageElement.innerText;
    }

    try {
        await navigator.clipboard.writeText(textToCopy);

        // Show feedback by updating the copy button temporarily
        const copyButton = messageElement.querySelector('.copy-btn');
        if (copyButton) {
            const originalHTML = copyButton.innerHTML;
            copyButton.innerHTML = `
                <svg class="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
                    <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path>
                </svg>
                <span>Copied!</span>
            `;

            setTimeout(() => {
                copyButton.innerHTML = originalHTML;
            }, 2000);
        }

        showNotification('Message copied to clipboard', 'success');
    } catch (err) {
        console.error('Failed to copy text:', err);
        showNotification('Failed to copy message', 'error');
    }
}

// Regenerate response function
async function regenerateResponse() {
    // Find the last user message
    let messages = document.querySelectorAll('#chat-messages .bg-blue-100');
    if (messages.length === 0) return;

    const lastUserMessageDiv = messages[messages.length - 1];
    const lastUserMessage = lastUserMessageDiv.textContent.trim();

    if (!lastUserMessage) return;

    // Remove the last assistant message from chat history
    if (chatHistory.length >= 2 && chatHistory[chatHistory.length - 1].role === 'assistant') {
        chatHistory = chatHistory.slice(0, -2);
    }

    // Remove the last pair of messages from the UI
    messages = document.querySelectorAll('#chat-messages > div');
    if (messages.length > 0) {
        const lastConversation = messages[messages.length - 1];
        lastConversation.remove();
    }

    // Resend the last user message
    await sendChatMessage(lastUserMessage, false);
}

// Load sample questions when chat tab is activated
async function loadSampleQuestions() {
    try {
        const response = await api.fetchWithAuth('/api/v1/crew-chat/sample-questions');
        if (response.ok) {
            const data = await response.json();
            const container = document.getElementById('sample-questions');
            if (container && data.questions) {
                container.innerHTML = data.questions.map(q =>
                    `<button onclick="selectSampleQuestion('${q.replace(/'/g, '\\\'')}')" 
                             class="bg-gray-100 hover:bg-gray-200 text-gray-700 px-3 py-2 rounded-lg text-sm transition-colors">
                        ${q}
                    </button>`
                ).join('');
            }
        }
    } catch (error) {
        console.error('Error loading sample questions:', error);
    }
}

// Select sample question
function selectSampleQuestion(question) {
    document.getElementById('chat-input').value = question;
    sendChatMessage();
}

// Send chat message
async function sendChatMessage(messageOverride = null, addToDisplay = true) {
    const input = document.getElementById('chat-input');
    const message = messageOverride || input.value.trim();

    if (!message) return;

    // Clear input
    input.value = '';

    // Create a new conversation if none exists or use existing empty one
    if (!currentConversationId) {
        await findOrCreateConversation();
    }

    // Remove placeholder if it exists
    const placeholder = document.getElementById('chat-placeholder');
    if (placeholder) {
        placeholder.remove();
    }

    // Add user message to chat if needed
    if (addToDisplay) {
        addMessageToChat('user', message, {
            timestamp: new Date().toISOString(),
            showTimestamp: true
        });
    }

    // Add user message to history
    chatHistory.push({ role: 'user', content: message });

    // Show loading indicator
    showChatLoader();

    try {
        const response = await api.fetchWithAuth('/api/v1/crew-chat/chat', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                message: message,
                conversation_id: currentConversationId,
                chat_history: chatHistory
            })
        });

        if (!response.ok) {
            throw new Error('Failed to send message');
        }

        const data = await response.json();

        console.log('Chat response received:', {
            chatId: data.chat_id,
            filePaths: data.file_paths
        });

        // Add assistant response to chat
        addMessageToChat('assistant', data.message, {
            timestamp: new Date().toISOString(),
            showTimestamp: true,
            filePaths: data.file_paths,
            chatId: data.chat_id,
            isFavorite: false
        });

        // Update chat history
        chatHistory.push(
            { role: 'assistant', content: data.message }
        );

        // Increment total chat count (since a new conversation was saved to database)
        updateChatCount(totalChatCount + 1);

        // Hide loading indicator
        hideChatLoader();

    } catch (error) {
        console.error('Error sending message:', error);

        // Show error message in chat
        const errorMessage = error.message === 'Failed to send message'
            ? 'Sorry, I encountered an error while processing your request. Please check your connection and try again.'
            : 'Sorry, I encountered an error while processing your request. Please try again.';

        addMessageToChat('assistant', errorMessage, {
            timestamp: new Date().toISOString(),
            showTimestamp: true,
            isError: true
        });

        // Hide loading indicator
        hideChatLoader();
    }
}

// Create message element
function createMessageElement(role, content, metadata = {}) {
    const messageDiv = document.createElement('div');
    messageDiv.className = role === 'user' ? 'flex justify-end' : 'flex justify-start';

    const contentDiv = document.createElement('div');
    contentDiv.className = role === 'user'
        ? 'bg-blue-100 text-blue-900 px-4 py-3 rounded-lg max-w-3xl shadow-sm'
        : 'bg-white text-gray-800 px-4 py-3 rounded-lg max-w-4xl shadow-sm border border-gray-200';

    if (metadata.isError) {
        contentDiv.className += ' border-red-200 bg-red-50 text-red-800';
    }

    // Add content with proper data attributes for copying
    const messageContent = document.createElement('div');
    messageContent.className = role === 'assistant' ? 'message-content markdown-content' : 'message-content';
    messageContent.setAttribute('data-original-content', content);

    if (role === 'assistant' && typeof marked !== 'undefined') {
        messageContent.innerHTML = marked.parse(content);
    } else {
        messageContent.textContent = content;
    }

    contentDiv.appendChild(messageContent);

    // Add timestamp if provided
    if (metadata.showTimestamp && metadata.timestamp) {
        const timeDiv = document.createElement('div');
        timeDiv.className = 'text-xs text-gray-500 mt-2';
        timeDiv.textContent = formatTimestamp(metadata.timestamp);
        contentDiv.appendChild(timeDiv);
    }

    // Add file downloads if provided
    if (metadata.filePaths && metadata.filePaths.length > 0) {
        const filesDiv = document.createElement('div');
        filesDiv.className = 'mt-3 space-y-2';

        metadata.filePaths.forEach(filePath => {
            const fileName = filePath.split('/').pop();
            const fileExtension = fileName.split('.').pop().toLowerCase();
            const supportedPreviewTypes = ['png', 'jpg', 'jpeg', 'svg', 'pdf', 'docx', 'pptx', 'csv', 'xls', 'xlsx'];
            const showPreview = supportedPreviewTypes.includes(fileExtension);
            
            const fileDiv = document.createElement('div');
            fileDiv.className = 'flex items-center space-x-2 bg-gray-50 p-2 rounded border';

            let buttonsHTML = '';
            if (showPreview) {
                buttonsHTML = `
                    <button onclick="previewDocument('${escapeHtml(fileName)}')"
                            class="text-blue-600 hover:text-blue-800 text-sm px-2 py-1 rounded hover:bg-blue-50 transition-colors flex items-center gap-1">
                        <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path>
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"></path>
                        </svg>
                        Preview
                    </button>
                    <a href="/api/v1/crew-chat/download/${encodeURIComponent(fileName)}"
                       target="_blank"
                       class="text-blue-600 hover:text-blue-800 text-sm px-2 py-1 rounded hover:bg-blue-50 transition-colors flex items-center gap-1">
                        <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M9 19l3 3m0 0l3-3m-3 3V10"></path>
                        </svg>
                        Download
                    </a>
                `;
            } else {
                buttonsHTML = `
                    <a href="/api/v1/crew-chat/download/${encodeURIComponent(fileName)}"
                       target="_blank"
                       class="text-blue-600 hover:text-blue-800 text-sm px-2 py-1 rounded hover:bg-blue-50 transition-colors">
                        Download
                    </a>
                `;
            }

            fileDiv.innerHTML = `
                <svg class="w-4 h-4 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                </svg>
                <span class="text-sm text-gray-700 flex-1">${escapeHtml(fileName)}</span>
                ${buttonsHTML}
            `;

            filesDiv.appendChild(fileDiv);
        });

        contentDiv.appendChild(filesDiv);
    }

    // Add action buttons for assistant messages
    if (role === 'assistant') {
        const actionsDiv = document.createElement('div');
        actionsDiv.className = 'flex items-center justify-between mt-3 pt-2 border-t border-gray-100';

        // Left side - Copy button
        const leftActions = document.createElement('div');
        leftActions.className = 'flex items-center space-x-2';

        const copyButton = document.createElement('button');
        copyButton.className = 'copy-btn text-xs text-gray-500 hover:text-gray-700 flex items-center space-x-1';
        copyButton.innerHTML = `
            <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"></path>
            </svg>
            <span>Copy</span>
        `;
        copyButton.onclick = () => copyMessage(messageDiv);
        leftActions.appendChild(copyButton);

        // Right side - Other action buttons
        const rightActions = document.createElement('div');
        rightActions.className = 'flex items-center space-x-2';

        // Regenerate button (only show for the last assistant message)
        const regenerateButton = document.createElement('button');
        regenerateButton.className = 'text-xs text-gray-500 hover:text-gray-700 flex items-center space-x-1';
        regenerateButton.innerHTML = `
            <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"></path>
            </svg>
            <span>Regenerate</span>
        `;
        regenerateButton.onclick = regenerateResponse;

        // Favorite button (show for all messages with chat ID)
        if (metadata.chatId) {
            const favoriteButton = document.createElement('button');
            favoriteButton.className = `favorite-btn text-xs ${metadata.isFavorite ? 'text-yellow-500 fill-current' : 'text-gray-400'} hover:text-yellow-500 flex items-center space-x-1`;
            favoriteButton.innerHTML = `
                <svg class="w-3 h-3" fill="${metadata.isFavorite ? 'currentColor' : 'none'}" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z"></path>
                </svg>
                <span>${metadata.isFavorite ? 'Favorited' : 'Favorite'}</span>
            `;
            favoriteButton.onclick = () => toggleChatFavorite(metadata.chatId, metadata.isFavorite);
            favoriteButton.setAttribute('data-chat-id', metadata.chatId);

            rightActions.appendChild(favoriteButton);
        }

        // Only show regenerate button for the last assistant message
        const assistantMessages = document.querySelectorAll('#chat-messages .justify-start');
        if (assistantMessages.length === 0) { // This will be the first, so also the last
            rightActions.appendChild(regenerateButton);
        }

        // Add both sides to the actions div
        actionsDiv.appendChild(leftActions);
        actionsDiv.appendChild(rightActions);

        contentDiv.appendChild(actionsDiv);
    }

    messageDiv.appendChild(contentDiv);
    return messageDiv;
}

// Add message to chat display
function addMessageToChat(role, content, metadata = {}) {
    let messagesContainer = document.getElementById('chat-messages');
    const messageElement = createMessageElement(role, content, metadata);
    messagesContainer.appendChild(messageElement);

    // Update regenerate button visibility - only show on the last assistant message
    const assistantMessages = document.querySelectorAll('#chat-messages .justify-start');
    assistantMessages.forEach((msg, index) => {
        const regenerateBtn = msg.querySelector('button[onclick="regenerateResponse()"]');
        if (regenerateBtn) {
            regenerateBtn.style.display = index === assistantMessages.length - 1 ? 'flex' : 'none';
        }
    });

    // Scroll to bottom smoothly
    messagesContainer = document.getElementById('chat-messages');
    const scrollContainer = messagesContainer.parentElement;
    if (scrollContainer) {
        scrollContainer.scrollTop = scrollContainer.scrollHeight;
    }
}

// Update conversation buttons visibility
function updateConversationButtons() {
    const hasConversation = currentConversationId && conversations.some(c => c.id === currentConversationId);
    const editBtn = document.getElementById('edit-title-btn');
    const deleteBtn = document.getElementById('delete-conversation-btn');
    const selector = document.getElementById('conversation-selector');

    if (editBtn) {
        editBtn.style.display = hasConversation ? 'inline-flex' : 'none';
    }

    if (deleteBtn) {
        deleteBtn.style.display = hasConversation ? 'inline-flex' : 'none';
    }

    if (selector && hasConversation) {
        selector.style.display = 'block';
    }
}

// Start editing conversation title
function startEditingTitle() {
    const selector = document.getElementById('conversation-selector');
    if (!selector || !selector.value) return;

    const currentTitle = selector.options[selector.selectedIndex].text;
    const newTitle = prompt('Enter new conversation title:', currentTitle);

    if (newTitle && newTitle.trim() && newTitle.trim() !== currentTitle) {
        updateConversationTitle(selector.value, newTitle.trim());
    }
}

// Update conversation title via API
async function updateConversationTitle(conversationId, title) {
    try {
        const response = await api.fetchWithAuth(`/api/v1/crew-chat/conversations/${conversationId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ title: title })
        });

        if (!response.ok) {
            throw new Error('Failed to update conversation title');
        }

        // Reload conversations to reflect the change
        await loadConversations();
    } catch (error) {
        console.error('Error updating conversation title:', error);
        alert('Failed to update conversation title. Please try again.');
    }
}

// Confirm and delete conversation
function confirmDeleteConversation() {
    const selector = document.getElementById('conversation-selector');
    if (!selector || !selector.value) return;

    const title = selector.options[selector.selectedIndex].text;

    if (confirm(`Are you sure you want to delete the conversation "${title}"? This will delete all messages in this conversation and cannot be undone.`)) {
        deleteConversation(selector.value);
    }
}

// Delete conversation via API
async function deleteConversation(conversationId) {
    try {
        const response = await api.fetchWithAuth(`/api/v1/crew-chat/conversations/${conversationId}`, {
            method: 'DELETE'
        });

        if (!response.ok) {
            throw new Error('Failed to delete conversation');
        }

        // Remove from conversations array
        conversations = conversations.filter(conv => conv.id !== conversationId);

        // Clear current conversation if it was deleted
        if (currentConversationId === conversationId) {
            currentConversationId = null;
            localStorage.removeItem('currentConversationId');
            chatHistory = [];

            // Clear chat display
            const messagesContainer = document.getElementById('chat-messages');
            messagesContainer.innerHTML = `
                <div class="text-center text-gray-500 py-8" id="chat-placeholder">
                    <div class="text-6xl mb-4">💬</div>
                    <h3 class="text-lg font-medium mb-2">Start a Conversation</h3>
                    <p>Start a conversation by typing a question below or clicking a sample question.</p>
                </div>
            `;
            updateChatCount(0);
        }

        // Update conversations list
        updateConversationsList();

    } catch (error) {
        console.error('Error deleting conversation:', error);
        alert('Failed to delete conversation. Please try again.');
    }
}

// Update onConversationChange to handle button visibility
const originalOnConversationChange = onConversationChange;
onConversationChange = async function(conversationId) {
    await originalOnConversationChange(conversationId);
    updateConversationButtons();
};

// Load sample questions and chat history when chat tab becomes active
document.addEventListener('DOMContentLoaded', function() {
    const chatTabButton = document.querySelector('[data-tab="chat"]');
    if (chatTabButton) {
        let chatInitialized = false;

        chatTabButton.addEventListener('click', function() {
            if (!chatInitialized) {
                loadSampleQuestions();
                chatInitialized = true;
            }

            // Initialize chat history if not already initialized
            if (!chatInitialized) {
                initializeChatHistory();
                chatInitialized = true;
            }
        });
    }
});

// Format timestamp for display
function formatTimestamp(timestamp) {
    const date = new Date(timestamp);
    return date.toLocaleString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

// Modified toggle favorite function to work with chat messages
async function toggleChatFavorite(chatId, isFavorite) {
    try {
        const response = await api.fetchWithAuth(`/api/v1/crew-chat/chat/${chatId}/favorite`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                is_favorite: !isFavorite
            })
        });

        if (response.ok) {
            const data = await response.json();
            
            // Show notification
            const message = data.is_favorite ? 'Added to favorites' : 'Removed from favorites';
            showNotification(message, 'success');

            // Update the star icon in chat if it exists
            updateChatStarIcon(chatId, data.is_favorite);
            
            // Update the button text and classes immediately for better UX
            const favoriteButton = document.querySelector(`[data-chat-id="${chatId}"]`);
            if (favoriteButton) {
                updateFavoriteButton(favoriteButton, data.is_favorite);
            }

            // Refresh favorites tab if it's currently active
            const activeTab = document.querySelector('.tab-button.active');
            if (activeTab && activeTab.getAttribute('data-tab') === 'favorites') {
                loadFavoriteChats(favoritesData.currentOffset);
            }
        } else {
            throw new Error('Failed to toggle favorite status');
        }

    } catch (error) {
        console.error('Error toggling favorite:', error);
        showNotification('Failed to update favorite status', 'error');
    }
}

function updateChatStarIcon(chatId, isFavorite) {
    const starButton = document.querySelector(`[data-chat-id="${chatId}"]`);
    if (starButton) {
        updateFavoriteButton(starButton, isFavorite);
    }
}

// Update favorite button appearance and text
function updateFavoriteButton(favoriteButton, isFavorite) {
    const starIcon = favoriteButton.querySelector('svg');
    const starText = favoriteButton.querySelector('span');
    
    if (starIcon) {
        if (isFavorite) {
            starIcon.setAttribute('fill', 'currentColor');
            favoriteButton.classList.add('text-yellow-500');
            favoriteButton.classList.remove('text-gray-400');
        } else {
            starIcon.setAttribute('fill', 'none');
            favoriteButton.classList.add('text-gray-400');
            favoriteButton.classList.remove('text-yellow-500');
        }
    }
    
    if (starText) {
        starText.textContent = isFavorite ? 'Favorited' : 'Favorite';
    }
}

// ===== FAVORITES FUNCTIONALITY =====

let favoritesData = {
    currentOffset: 0,
    limit: 10,
    totalCount: 0,
    hasMore: false
};

function initializeFavorites() {
    window.favoritesInitialized = true;
    loadFavoriteChats();
}

async function loadFavoriteChats(offset = 0) {
    try {
        const favoritesLoading = document.getElementById('favorites-loading');
        const favoritesContainer = document.getElementById('favorites-container');
        const favoritesEmpty = document.getElementById('favorites-empty');
        const favoritesPagination = document.getElementById('favorites-pagination');

        // Show loading state
        if (favoritesLoading) favoritesLoading.style.display = 'block';
        if (favoritesContainer) favoritesContainer.style.display = 'none';
        if (favoritesEmpty) favoritesEmpty.style.display = 'none';
        if (favoritesPagination) favoritesPagination.style.display = 'none';

        const response = await api.fetchWithAuth(`/api/v1/crew-chat/chat/favorites?offset=${offset}&limit=${favoritesData.limit}`);

        if (!response.ok) {
            throw new Error('Failed to fetch favorite chats');
        }

        const data = await response.json();
        favoritesData.currentOffset = offset;
        favoritesData.totalCount = data.total_count;
        favoritesData.hasMore = data.has_more;

        // Hide loading
        if (favoritesLoading) favoritesLoading.style.display = 'none';

        if (data.favorite_chats && data.favorite_chats.length > 0) {
            // Show favorites
            renderFavoriteChats(data.favorite_chats);
            if (favoritesContainer) favoritesContainer.style.display = 'block';
            if (favoritesPagination) favoritesPagination.style.display = 'flex';
            updateFavoritesPagination();
        } else {
            // Show empty state
            if (favoritesEmpty) favoritesEmpty.style.display = 'block';
        }

    } catch (error) {
        console.error('Error loading favorite chats:', error);
        const favoritesLoading = document.getElementById('favorites-loading');
        const favoritesEmpty = document.getElementById('favorites-empty');
        if (favoritesLoading) favoritesLoading.style.display = 'none';
        if (favoritesEmpty) favoritesEmpty.style.display = 'block';
        showNotification('Failed to load favorite chats', 'error');
    }
}

function renderFavoriteChats(favoriteChats) {
    const container = document.getElementById('favorites-container');
    if (!container) return;

    container.innerHTML = '';

    favoriteChats.forEach(chat => {
        const chatElement = createFavoriteChatElement(chat);
        container.appendChild(chatElement);
    });
}

function createFavoriteChatElement(chat) {
    const chatDiv = document.createElement('div');
    chatDiv.className = 'bg-white border border-gray-200 rounded-lg p-4 shadow-sm hover:shadow-md transition-shadow';

    // Build the HTML content step by step to avoid template literal issues
    let htmlContent = `
        <div class="flex justify-between items-start mb-3">
            <div class="flex items-center gap-2">
                <span class="text-sm font-medium text-gray-900">${escapeHtml(chat.conversation_title || 'Untitled Conversation')}</span>
                <svg class="w-4 h-4 text-yellow-500 fill-current" viewBox="0 0 24 24">
                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
                </svg>
            </div>
            <div class="flex items-center gap-2">
                <span class="text-xs text-gray-500">${formatDate(chat.created_at)}</span>
                <button onclick="toggleChatFavorite(${chat.id}, true)"
                        class="text-yellow-500 hover:text-gray-400 transition-colors"
                        title="Remove from favorites">
                    <svg class="w-4 h-4 fill-current" viewBox="0 0 24 24">
                        <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
                    </svg>
                </button>
            </div>
        </div>

        <div class="mb-3">
            <div class="text-sm font-medium text-gray-700 mb-1">Question:</div>
            <div class="text-sm text-gray-600 bg-blue-50 p-2 rounded">${escapeHtml(chat.user_message)}</div>
        </div>

        <div class="mb-3">
            <div class="text-sm font-medium text-gray-700 mb-1">Answer:</div>
            <div class="text-sm text-gray-600 bg-gray-50 p-2 rounded markdown-content">
                ${typeof marked !== 'undefined' ? marked.parse(chat.assistant_message) : escapeHtml(chat.assistant_message)}
            </div>
        </div>`;

    // Add file paths if they exist
    if (chat.file_paths && chat.file_paths.length > 0) {
        htmlContent += `
            <div class="mb-3">
                <div class="text-sm font-medium text-gray-700 mb-1">Generated Files:</div>
                <div class="flex flex-wrap gap-2">`;

        chat.file_paths.forEach(filePath => {
            const fileName = filePath.split('/').pop();
            const fileExtension = fileName.split('.').pop().toLowerCase();
            const supportedPreviewTypes = ['png', 'jpg', 'jpeg', 'svg', 'pdf', 'docx', 'pptx', 'csv', 'xls', 'xlsx'];
            const showPreview = supportedPreviewTypes.includes(fileExtension);

            htmlContent += `
                <div class="inline-flex items-center gap-1 text-xs bg-blue-100 text-blue-700 rounded overflow-hidden">`;

            if (showPreview) {
                htmlContent += `
                    <button onclick="previewDocument('${escapeHtml(fileName)}')"
                            class="px-2 py-1 hover:bg-blue-200 transition-colors flex items-center gap-1"
                            title="Preview ${escapeHtml(fileName)}">
                        <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path>
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"></path>
                        </svg>
                        Preview
                    </button>`;
            }

            htmlContent += `
                    <a href="/api/v1/crew-chat/download/${encodeURIComponent(fileName)}"
                       class="px-2 py-1 hover:bg-blue-200 transition-colors flex items-center gap-1 ${showPreview ? 'border-l border-blue-300' : ''}"
                       download
                       title="Download ${escapeHtml(fileName)}">
                        <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M9 19l3 3m0 0l3-3m-3 3V10"></path>
                        </svg>
                        ${showPreview ? 'Download' : escapeHtml(fileName)}
                    </a>
                </div>`;
        });

        htmlContent += `
                </div>
            </div>`;
    }

    htmlContent += `
        <div class="flex justify-between items-center text-xs text-gray-500">
            <span>Conversation: ${escapeHtml(chat.conversation_id)}</span>
            <button onclick="navigateToConversation('${escapeHtml(chat.conversation_id)}')"
                    class="text-blue-600 hover:text-blue-800 transition-colors">
                View in Chat →
            </button>
        </div>`;

    chatDiv.innerHTML = htmlContent;
    return chatDiv;
}

function updateFavoritesPagination() {
    const currentRange = document.getElementById('favorites-current-range');
    const totalElement = document.getElementById('favorites-total');
    const prevBtn = document.getElementById('favorites-prev-btn');
    const nextBtn = document.getElementById('favorites-next-btn');

    if (!currentRange || !totalElement || !prevBtn || !nextBtn) return;

    const start = favoritesData.currentOffset + 1;
    const end = Math.min(favoritesData.currentOffset + favoritesData.limit, favoritesData.totalCount);

    currentRange.textContent = `${start}-${end}`;
    totalElement.textContent = favoritesData.totalCount;

    prevBtn.disabled = favoritesData.currentOffset === 0;
    nextBtn.disabled = !favoritesData.hasMore;
}

function loadPreviousFavorites() {
    if (favoritesData.currentOffset > 0) {
        const newOffset = Math.max(0, favoritesData.currentOffset - favoritesData.limit);
        loadFavoriteChats(newOffset);
    }
}

function loadNextFavorites() {
    if (favoritesData.hasMore) {
        const newOffset = favoritesData.currentOffset + favoritesData.limit;
        loadFavoriteChats(newOffset);
    }
}

function navigateToConversation(conversationId) {
    // Switch to chat tab
    switchToTab('chat');

    // Select the conversation
    setTimeout(() => {
        const conversationSelector = document.getElementById('conversation-selector');
        if (conversationSelector) {
            conversationSelector.value = conversationId;
            onConversationChange(conversationId);
        }
    }, 100);
}

function switchToTab(tabName) {
    const tabButton = document.querySelector(`[data-tab="${tabName}"]`);
    if (tabButton) {
        tabButton.click();
    }
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

// Parse CSV text into array of objects
function parseCSV(text) {
    const lines = text.split('\n').filter(line => line.trim());
    if (lines.length < 2) return [];

    const headers = lines[0].split(',').map(h => h.trim().replace(/"/g, ''));
    const data = [];

    for (let i = 1; i < lines.length; i++) {
        const values = lines[i].split(',').map(v => v.trim().replace(/"/g, ''));
        if (values.length === headers.length) {
            const row = {};
            headers.forEach((header, index) => {
                row[header] = values[index];
            });
            data.push(row);
        }
    }

    return { headers, data };
}

// Create CSV table HTML
function createCSVTable(csvData, fileName) {
    const container = document.createElement('div');
    container.className = 'w-full';

    if (!csvData.data || csvData.data.length === 0) {
        container.innerHTML = `
            <div class="text-center py-8 text-gray-600">
                <p>No data found in CSV file</p>
            </div>
        `;
        return container;
    }

    // Create table info header
    const infoDiv = document.createElement('div');
    infoDiv.className = 'mb-4 p-3 bg-gray-50 rounded-lg';
    infoDiv.innerHTML = `
        <div class="flex justify-between items-center text-sm text-gray-600">
            <span><strong>${fileName}</strong> - ${csvData.data.length} rows, ${csvData.headers.length} columns</span>
            <span>Showing ${Math.min(csvData.data.length, 100)} of ${csvData.data.length} rows</span>
        </div>
    `;
    container.appendChild(infoDiv);

    // Create scrollable table container
    const tableContainer = document.createElement('div');
    tableContainer.className = 'overflow-auto max-h-96 border border-gray-200 rounded-lg';

    const table = document.createElement('table');
    table.className = 'min-w-full divide-y divide-gray-200';

    // Create header
    const thead = document.createElement('thead');
    thead.className = 'bg-gray-50 sticky top-0';
    const headerRow = document.createElement('tr');

    csvData.headers.forEach(header => {
        const th = document.createElement('th');
        th.className = 'px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border-r border-gray-200';
        th.textContent = header;
        headerRow.appendChild(th);
    });

    thead.appendChild(headerRow);
    table.appendChild(thead);

    // Create body (limit to first 100 rows for performance)
    const tbody = document.createElement('tbody');
    tbody.className = 'bg-white divide-y divide-gray-200';

    const displayData = csvData.data.slice(0, 100);
    displayData.forEach((row, index) => {
        const tr = document.createElement('tr');
        tr.className = index % 2 === 0 ? 'bg-white' : 'bg-gray-50';

        csvData.headers.forEach(header => {
            const td = document.createElement('td');
            td.className = 'px-3 py-2 text-sm text-gray-900 border-r border-gray-200';
            td.textContent = row[header] || '';
            tr.appendChild(td);
        });

        tbody.appendChild(tr);
    });

    table.appendChild(tbody);
    tableContainer.appendChild(table);
    container.appendChild(tableContainer);

    // Add pagination info if there are more rows
    if (csvData.data.length > 100) {
        const paginationDiv = document.createElement('div');
        paginationDiv.className = 'mt-4 p-3 bg-yellow-50 border border-yellow-200 rounded-lg';
        paginationDiv.innerHTML = `
            <div class="flex items-center text-sm text-yellow-800">
                <svg class="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 20 20">
                    <path fill-rule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clip-rule="evenodd"></path>
                </svg>
                Only the first 100 rows are displayed. Download the file to view all ${csvData.data.length} rows.
            </div>
        `;
        container.appendChild(paginationDiv);
    }

    return container;
}

// Preview document function
async function previewDocument(fileName) {
    const fileExtension = fileName.split('.').pop().toLowerCase();
    const supportedPreviewTypes = ['png', 'jpg', 'jpeg', 'svg', 'pdf', 'docx', 'pptx', 'csv', 'xls', 'xlsx'];

    if (!supportedPreviewTypes.includes(fileExtension)) {
        showNotification('Preview not available for this file type', 'warning');
        return;
    }

    try {
        const response = await api.fetchWithAuth(`/api/v1/crew-chat/download/${fileName}`);
        if (!response.ok) {
            throw new Error('Failed to fetch file');
        }

        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);

        // Create preview modal
        const modal = document.createElement('div');
        modal.className = 'fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4';
        modal.onclick = (e) => {
            if (e.target === modal) {
                document.body.removeChild(modal);
                window.URL.revokeObjectURL(url);
            }
        };

        const modalContent = document.createElement('div');
        modalContent.className = 'bg-white rounded-lg shadow-xl max-w-6xl max-h-[90vh] overflow-hidden';

        // Modal header
        const header = document.createElement('div');
        header.className = 'bg-gray-100 px-4 py-3 flex justify-between items-center border-b';
        header.innerHTML = `
            <h3 class="text-lg font-medium text-gray-900">${fileName}</h3>
            <div class="flex gap-2">
                <button onclick="downloadFileDirectly('${fileName}')" class="px-3 py-1 bg-blue-500 text-white rounded hover:bg-blue-600 text-sm">
                    Download
                </button>
                <button onclick="this.closest('.fixed').remove(); window.URL.revokeObjectURL('${url}');" class="text-gray-400 hover:text-gray-600">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                    </svg>
                </button>
            </div>
        `;
        modalContent.appendChild(header);

        // Modal body
        const body = document.createElement('div');
        body.className = 'p-4 overflow-auto';
        body.style.maxHeight = 'calc(90vh - 120px)';

        if (['png', 'jpg', 'jpeg', 'svg'].includes(fileExtension)) {
            const img = document.createElement('img');
            img.src = url;
            img.className = 'max-w-full h-auto mx-auto';
            body.appendChild(img);
        } else if (fileExtension === 'pdf') {
            const iframe = document.createElement('iframe');
            iframe.src = url;
            iframe.className = 'w-full';
            iframe.style.height = 'calc(90vh - 120px)';
            body.appendChild(iframe);
        } else if (['docx', 'pptx'].includes(fileExtension)) {
            // For Office documents, we'll use Office Online viewer
            const viewerUrl = 'https://view.officeapps.live.com/op/embed.aspx?src=' + encodeURIComponent(window.location.origin + '/api/v1/crew-chat/download/' + fileName);
            const iframe = document.createElement('iframe');
            iframe.src = viewerUrl;
            iframe.className = 'w-full';
            iframe.style.height = 'calc(90vh - 120px)';
            body.appendChild(iframe);
        } else if (fileExtension === 'csv') {
            // For CSV files, parse and display as a table
            const text = await blob.text();
            const csvData = parseCSV(text);
            const tableContainer = createCSVTable(csvData, fileName);
            body.appendChild(tableContainer);
        } else if (['xls', 'xlsx'].includes(fileExtension)) {
            // For Excel files, use Office Online viewer
            const viewerUrl = 'https://view.officeapps.live.com/op/embed.aspx?src=' + encodeURIComponent(window.location.origin + '/api/v1/crew-chat/download/' + fileName);
            const iframe = document.createElement('iframe');
            iframe.src = viewerUrl;
            iframe.className = 'w-full';
            iframe.style.height = 'calc(90vh - 120px)';

            // Add fallback message for Excel files
            const fallbackDiv = document.createElement('div');
            fallbackDiv.className = 'text-center py-8 text-gray-600';
            fallbackDiv.innerHTML = `
                <div class="mb-4">
                    <svg class="mx-auto h-16 w-16 text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                    </svg>
                </div>
                <h3 class="text-lg font-medium text-gray-900 mb-2">${fileName}</h3>
                <p class="text-sm text-gray-600 mb-4">Excel file preview</p>
                <p class="text-xs text-gray-500">If the preview doesn't load, please download the file to view it locally.</p>
            `;

            body.appendChild(fallbackDiv);
            body.appendChild(iframe);

            // Handle iframe load errors
            iframe.onerror = () => {
                iframe.style.display = 'none';
                fallbackDiv.innerHTML += '<p class="text-red-500 mt-2">Preview unavailable. Please download to view.</p>';
            };
        }

        modalContent.appendChild(body);
        modal.appendChild(modalContent);
        document.body.appendChild(modal);

    } catch (error) {
        console.error('Preview error:', error);
        showNotification('Failed to preview document', 'error');
    }
}

// Download file directly
async function downloadFileDirectly(fileName) {
    try {
        const response = await api.fetchWithAuth(`/api/v1/crew-chat/download/${fileName}`);
        if (response.ok) {
            const blob = await response.blob();
            const url = window.URL.createObjectURL(blob);
            const downloadLink = document.createElement('a');
            downloadLink.href = url;
            downloadLink.download = fileName;
            document.body.appendChild(downloadLink);
            downloadLink.click();
            document.body.removeChild(downloadLink);
            window.URL.revokeObjectURL(url);
        } else {
            console.error('Download failed:', response.statusText);
            showNotification('Failed to download file', 'error');
        }
    } catch (error) {
        console.error('Download error:', error);
        showNotification('Failed to download file', 'error');
    }
}

// Utility function for notifications (if not defined elsewhere)
function showNotification(message, type = 'info') {
    // Create notification element if it doesn't exist
    let notification = document.getElementById('notification');
    if (!notification) {
        notification = document.createElement('div');
        notification.id = 'notification';
        notification.className = 'fixed top-4 right-4 z-50 px-4 py-2 rounded-lg shadow-lg transition-all duration-300';
        document.body.appendChild(notification);
    }

    // Set message and style based on type
    notification.textContent = message;
    notification.className = 'fixed top-4 right-4 z-50 px-4 py-2 rounded-lg shadow-lg transition-all duration-300';

    switch (type) {
        case 'success':
            notification.className += ' bg-green-500 text-white';
            break;
        case 'error':
            notification.className += ' bg-red-500 text-white';
            break;
        case 'warning':
            notification.className += ' bg-yellow-500 text-white';
            break;
        default:
            notification.className += ' bg-blue-500 text-white';
    }

    // Show notification
    notification.style.opacity = '1';
    notification.style.transform = 'translateY(0)';

    // Hide after 3 seconds
    setTimeout(() => {
        notification.style.opacity = '0';
        notification.style.transform = 'translateY(-20px)';
    }, 3000);
}

// Show chat loader
function showChatLoader() {
    const sendButton = document.querySelector('button[onclick="sendChatMessage()"]');
    if (sendButton) {
        sendButton.disabled = true;
        sendButton.innerHTML = `
            <div class="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
            Sending...
        `;
    }
    
    // Disable input
    const input = document.getElementById('chat-input');
    if (input) {
        input.disabled = true;
        input.style.opacity = '0.6';
    }
}

// Hide chat loader
function hideChatLoader() {
    const sendButton = document.querySelector('button[onclick="sendChatMessage()"]');
    if (sendButton) {
        sendButton.disabled = false;
        sendButton.innerHTML = `
            <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                      d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8"></path>
            </svg>
            Send
        `;
    }
    
    // Enable input
    const input = document.getElementById('chat-input');
    if (input) {
        input.disabled = false;
        input.style.opacity = '1';
    }
}

// Toggle sample questions visibility
function toggleSampleQuestions() {
    const container = document.getElementById('sample-questions-container');
    const toggleText = document.getElementById('sample-toggle-text');
    const toggleIcon = document.getElementById('sample-toggle-icon');
    
    if (!container || !toggleText || !toggleIcon) return;
    
    const isHidden = container.style.maxHeight === '0px' || container.style.maxHeight === '';
    
    if (isHidden) {
        // Show questions
        container.style.maxHeight = '300px';
        toggleText.textContent = 'Hide';
        toggleIcon.style.transform = 'rotate(0deg)';
    } else {
        // Hide questions
        container.style.maxHeight = '0px';
        toggleText.textContent = 'Show';
        toggleIcon.style.transform = 'rotate(-90deg)';
    }
}