from typing import List, Optional
from pydantic import BaseModel, Field

# --- Aadhaar Models ---
class AadhaarKeyValuePair(BaseModel):
    key: str
    value: str
    bbox: Optional[List[int]] = Field(default=None, description="Bounding box of the value [ymin, xmin, ymax, xmax] (0-1000)")

class AadhaarExtractionResult(BaseModel):
    key_value_pairs: List[AadhaarKeyValuePair] = Field(alias="key-value-pairs", default_factory=list)

    class Config:
        populate_by_name = True

class AadhaarPageExtraction(BaseModel):
    page_number: int
    key_value_pairs: List[AadhaarKeyValuePair] = Field(alias="key-value-pairs", default_factory=list)

    class Config:
        populate_by_name = True

# --- Invoice Models ---
class InvoiceKeyValuePair(BaseModel):
    key: str
    value: str
    bbox: Optional[List[int]] = Field(default=None, description="Bounding box of the value [ymin, xmin, ymax, xmax] (0-1000)")

class InvoiceTerm(BaseModel):
    header: str
    content: List[str] = Field(description="Point by point extraction of the terms")

class InvoiceTable(BaseModel):
    name: Optional[str] = None
    columns: List[str]
    rows: List[List[str]]

class InvoiceExtractionResult(BaseModel):
    key_value_pairs: List[InvoiceKeyValuePair] = Field(alias="key-value-pairs", default_factory=list)
    tables: List[InvoiceTable] = Field(default_factory=list)
    terms: List[InvoiceTerm] = Field(default_factory=list)

    class Config:
        populate_by_name = True

class InvoicePageExtraction(BaseModel):
    page_number: int
    key_value_pairs: List[InvoiceKeyValuePair] = Field(alias="key-value-pairs", default_factory=list)
    tables: List[InvoiceTable] = Field(default_factory=list)
    terms: List[InvoiceTerm] = Field(default_factory=list)

    class Config:
        populate_by_name = True
