from typing import List, Optional
from pydantic import BaseModel

class InvoiceListResponse(BaseModel):
    invoice_id: str
    original_filename: Optional[str] = None
    title: Optional[str] = None
    status: Optional[str] = None
    username: Optional[str] = None
    company_name: Optional[str] = None
    location_name: Optional[str] = None
    page_count: Optional[int] = None
    created_at: Optional[str] = None  # ISO string

    class Config:
        orm_mode = True


class PaginatedInvoiceResponse(BaseModel):
    items: List[InvoiceListResponse]
    total: int
    page: int
    page_size: int
    
class GenerateSummaryRequest(BaseModel):
    prompt: Optional[str] = None


class GenerateSummaryResponse(BaseModel):
    id: int
    invoice_id: str
    summary_text: str
    generated_prompt: Optional[str]
    word_count: Optional[int]
    generation_method: str



class AadhaarListResponse(BaseModel):
    aadhaar_id: str
    original_filename: Optional[str] = None
    title: Optional[str] = None
    status: Optional[str] = None
    username: Optional[str] = None
    company_name: Optional[str] = None
    location_name: Optional[str] = None
    page_count: Optional[int] = None
    created_at: Optional[str] = None  # ISO string

    class Config:
        orm_mode = True


class PaginatedAadhaarResponse(BaseModel):
    items: List[AadhaarListResponse]
    total: int
    page: int
    page_size: int

class AadhaarMobileExtractResponse(BaseModel):
    extraction_json: dict
    b64_images: List[str]
    original_filename: str
    page_count: int

class AadhaarMobileConfirmRequest(BaseModel):
    extraction_json: dict
    b64_images: List[str]
    original_filename: str
    company_id: int
    location_id: int
    page_count: int

class InvoiceMobileExtractResponse(BaseModel):
    extraction_json: dict
    b64_images: List[str]
    original_filename: str
    page_count: int

class InvoiceMobileConfirmRequest(BaseModel):
    extraction_json: dict
    b64_images: List[str]
    original_filename: str
    company_id: int
    page_count: int
    location_id: int
