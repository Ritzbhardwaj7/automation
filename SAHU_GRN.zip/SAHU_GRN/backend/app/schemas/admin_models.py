from typing import Optional
from pydantic import BaseModel

class UserCreate(BaseModel):
    username: str
    password: str
    full_name: Optional[str] = None
    role: str = "user"

class CompanyCreate(BaseModel):
    name: str

class LocationCreate(BaseModel):
    name: str

class AccessCreate(BaseModel):
    user_id: int
    company_id: int
    location_id: int
