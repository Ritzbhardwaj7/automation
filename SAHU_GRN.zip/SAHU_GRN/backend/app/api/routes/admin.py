from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status
from sqlmodel import Session, select, delete
from app.db.session import get_db
from app.db.db_models import User, Company, Location, UserAccess
from app.core.auth import get_current_user, get_password_hash
from pydantic import BaseModel

router = APIRouter()

from app.schemas.admin_models import UserCreate, CompanyCreate, LocationCreate, AccessCreate

def check_admin(current_user: User = Depends(get_current_user)):
    if current_user.role != "admin":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Only admins can perform this action"
        )
    return current_user

# User Management
@router.get("/users", dependencies=[Depends(check_admin)])
async def get_users(db: Session = Depends(get_db)):
    return db.exec(select(User)).all()

@router.post("/users", dependencies=[Depends(check_admin)])
async def create_user(user_in: UserCreate, db: Session = Depends(get_db)):
    existing = db.exec(select(User).where(User.username == user_in.username)).first()
    if existing:
        raise HTTPException(status_code=400, detail="Username already exists")
    
    user = User(
        username=user_in.username,
        password_hash=get_password_hash(user_in.password),
        full_name=user_in.full_name,
        role=user_in.role
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return user

@router.delete("/users/{user_id}", dependencies=[Depends(check_admin)])
async def delete_user(user_id: int, db: Session = Depends(get_db)):
    user = db.get(User, user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    db.delete(user)
    db.commit()
    return {"detail": "User deleted"}

# Company Management
@router.get("/companies", dependencies=[Depends(check_admin)])
async def get_companies(db: Session = Depends(get_db)):
    return db.exec(select(Company)).all()

@router.post("/companies", dependencies=[Depends(check_admin)])
async def create_company(company_in: CompanyCreate, db: Session = Depends(get_db)):
    company = Company(name=company_in.name)
    db.add(company)
    db.commit()
    db.refresh(company)
    return company

# Location Management
@router.get("/locations", dependencies=[Depends(check_admin)])
async def get_locations(db: Session = Depends(get_db)):
    return db.exec(select(Location)).all()

@router.post("/locations", dependencies=[Depends(check_admin)])
async def create_location(location_in: LocationCreate, db: Session = Depends(get_db)):
    location = Location(name=location_in.name)
    db.add(location)
    db.commit()
    db.refresh(location)
    return location

# Access Management
@router.get("/access", dependencies=[Depends(check_admin)])
async def get_access_mappings(db: Session = Depends(get_db)):
    # Join with User, Company, Location to get names
    stmt = select(UserAccess, User.username, Company.name, Location.name).join(
        User, UserAccess.user_id == User.id
    ).join(
        Company, UserAccess.company_id == Company.id
    ).join(
        Location, UserAccess.location_id == Location.id
    )
    results = db.exec(stmt).all()
    
    output = []
    for access, username, company_name, location_name in results:
        output.append({
            "id": access.id,
            "user_id": access.user_id,
            "username": username,
            "company_id": access.company_id,
            "company_name": company_name,
            "location_id": access.location_id,
            "location_name": location_name
        })
    return output

@router.post("/access", dependencies=[Depends(check_admin)])
async def create_access_mapping(access_in: AccessCreate, db: Session = Depends(get_db)):
    # Check if already exists
    existing = db.exec(select(UserAccess).where(
        UserAccess.user_id == access_in.user_id,
        UserAccess.company_id == access_in.company_id,
        UserAccess.location_id == access_in.location_id
    )).first()
    if existing:
        raise HTTPException(status_code=400, detail="Mapping already exists")
    
    access = UserAccess(**access_in.model_dump())
    db.add(access)
    db.commit()
    db.refresh(access)
    return access

@router.delete("/access/{access_id}", dependencies=[Depends(check_admin)])
async def delete_access_mapping(access_id: int, db: Session = Depends(get_db)):
    access = db.get(UserAccess, access_id)
    if not access:
        raise HTTPException(status_code=404, detail="Mapping not found")
    db.delete(access)
    db.commit()
    return {"detail": "Mapping deleted"}
