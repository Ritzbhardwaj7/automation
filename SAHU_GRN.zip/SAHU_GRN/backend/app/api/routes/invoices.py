# app/api/routes/invoice.py

import os
from typing import Optional
import uuid
from datetime import datetime
import tempfile
from fastapi import APIRouter, UploadFile, File, HTTPException, Depends, status, Form
from fastapi.responses import FileResponse, JSONResponse
from sqlmodel import Session, func, select, delete

from app.db.session import get_db
from app.db.db_models import Invoice, InvoicePage, InvoiceSummary, User
from app.core.auth import get_current_user, verify_access
from app.services.extraction_service import ExtractionService
from app.core.config import settings
from app.schemas.api_models import InvoiceListResponse, PaginatedInvoiceResponse, GenerateSummaryRequest, GenerateSummaryResponse, InvoiceMobileExtractResponse, InvoiceMobileConfirmRequest

router = APIRouter()

@router.post("/upload")
async def upload_invoice(
    file: UploadFile = File(...),
    company_id: int = Form(...),
    location_id: int = Form(...),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    # Validate file type
    filename = file.filename.lower()
    if not (filename.endswith(".png") or filename.endswith(".jpg") or filename.endswith(".jpeg") or filename.endswith(".pdf")):
        raise HTTPException(status_code=400, detail="Only PNG/JPG/PDF invoices allowed")

    file_bytes = await file.read()
    
    if not verify_access(db, current_user, company_id, location_id):
        raise HTTPException(status_code=403, detail="Unauthorized access to this company/location")

    invoice_id = str(uuid.uuid4())
    extractor = ExtractionService()

    invoice, page_extractions, b64_images = await extractor.process_invoice(
        file_bytes=file_bytes,
        filename=file.filename,
        invoice_id=invoice_id
    )

    # Save invoice
    invoice.user_id = current_user.id
    invoice.company_id = company_id
    invoice.location_id = location_id
    
    db.add(invoice)
    db.commit()
    db.refresh(invoice)

    # Save all pages
    for idx, b64_image in enumerate(b64_images):
        page = InvoicePage(
            invoice_id=invoice_id,
            page_number=idx + 1,
            content="",  # can be updated with OCR later if needed
            base64_image=b64_image,
        )
        db.add(page)
    
    db.commit()

    return {
        "invoice_id": invoice_id,
        "message": "Invoice uploaded and processed",
        "extraction": invoice.extraction_json,
    }



@router.get("", response_model=PaginatedInvoiceResponse)
async def get_invoices(
    company_id: Optional[int] = None,
    location_id: Optional[int] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
    page: int = 1,
    page_size: int = 25,
    search: Optional[str] = None
):
    """
    Paginated list of invoices for a specific company and location.

    Query params:
    - page: 1-indexed page number
    - page_size: number of items per page (capped to 100)
    - search: optional case-insensitive search against filename, title, invoice_id, status
    """

    # sanitize page_size
    if page_size > 100:
        page_size = 100
    if page_size < 1:
        page_size = 25
    if page < 1:
        page = 1

    if not verify_access(db, current_user, company_id, location_id):
        raise HTTPException(status_code=403, detail="Unauthorized access to this company/location")

    from app.db.db_models import User as User_DB, Company, Location

    # Base query joining relevant tables
    base_query = select(Invoice, User_DB.username, Company.name.label("company_name"), Location.name.label("location_name")).join(
        User_DB, Invoice.user_id == User_DB.id
    ).join(
        Company, Invoice.company_id == Company.id
    ).join(
        Location, Invoice.location_id == Location.id
    ).where(
        Invoice.company_id == company_id,
        Invoice.location_id == location_id
    )

    # Apply search (case-insensitive)
    if search:
        s = f"%{search.lower()}%"
        base_query = base_query.where(
            (func.lower(Invoice.original_filename).like(s)) |
            (func.lower(Invoice.title).like(s)) |
            (func.lower(Invoice.invoice_id).like(s)) |
            (func.lower(Invoice.status).like(s)) |
            (func.lower(User_DB.username).like(s))
        )

    # Count total matching rows
    count_query = select(func.count()).select_from(Invoice)
    if search:
        s = f"%{search.lower()}%"
        count_query = count_query.join(User_DB, Invoice.user_id == User_DB.id).where(
            (func.lower(Invoice.original_filename).like(s)) |
            (func.lower(Invoice.title).like(s)) |
            (func.lower(Invoice.invoice_id).like(s)) |
            (func.lower(Invoice.status).like(s)) |
            (func.lower(User_DB.username).like(s))
        )

    total_result = db.exec(count_query).one()
    # db.exec(...).one() might return an int or a tuple like (N,)
    try:
        total = int(total_result)
    except Exception:
        try:
            total = int(total_result[0])
        except Exception:
            total = 0

    # Pagination + ordering (newest first)
    offset = (page - 1) * page_size
    results = db.exec(
        base_query.order_by(Invoice.created_at.desc()).offset(offset).limit(page_size)
    ).all()

    # Map to response items (convert datetimes to ISO strings)
    items = []
    # results is a list of tuples: (Invoice, username, company_name, location_name)
    for invoice, username, company_name, location_name in results:
        created_iso = None
        if getattr(invoice, "created_at", None):
            if isinstance(invoice.created_at, datetime):
                created_iso = invoice.created_at.isoformat()
            else:
                created_iso = str(invoice.created_at)

        # optional small extraction summary - you can change this to whatever slice you prefer
        extraction_summary = None
        if getattr(invoice, "extraction_json", None):
            # don't send huge JSON blobs — give a small preview if present
            extraction_summary = invoice.extraction_json if isinstance(invoice.extraction_json, dict) else None

        items.append({
            "invoice_id": invoice.invoice_id,
            "original_filename": invoice.original_filename,
            "title": invoice.title,
            "status": invoice.status,
            "username": username,
            "company_name": company_name,
            "location_name": location_name,
            "page_count": invoice.page_count,
            "created_at": created_iso,
        })

    return PaginatedInvoiceResponse(
        items=items,
        total=total,
        page=page,
        page_size=page_size
    )
    
@router.get("/{invoice_id}")
async def get_invoice_detail(invoice_id: str, db: Session = Depends(get_db)):
    from app.db.db_models import User as User_DB, Company, Location
    
    result = db.exec(
        select(Invoice, User_DB.username, Company.name.label("company_name"), Location.name.label("location_name")).join(
            User_DB, Invoice.user_id == User_DB.id
        ).join(
            Company, Invoice.company_id == Company.id
        ).join(
            Location, Invoice.location_id == Location.id
        ).where(Invoice.invoice_id == invoice_id)
    ).one_or_none()

    if not result:
        raise HTTPException(status_code=404, detail="Invoice not found")
        
    invoice, username, company_name, location_name = result
    
    return {
        "invoice_id": invoice.invoice_id,
        "title": invoice.title,
        "original_filename": invoice.original_filename,
        "status": invoice.status,
        "username": username,
        "company_name": company_name,
        "location_name": location_name,
        "page_count": invoice.page_count,
        "extraction_json": invoice.extraction_json,
        "created_at": invoice.created_at.isoformat() if getattr(invoice, "created_at", None) else None,
    }
    
@router.get("/{invoice_id}/pages")
async def get_invoice_pages(invoice_id: str, db: Session = Depends(get_db)):
    pages = db.exec(select(InvoicePage).where(InvoicePage.invoice_id == invoice_id).order_by(InvoicePage.page_number)).all()
    # Return empty list rather than 404 to simplify UI handling
    return [
        {"page_number": p.page_number, "base64_image": p.base64_image, "created_at": (p.created_at.isoformat() if getattr(p, "created_at", None) else None)}
        for p in (pages or [])
    ]
    
@router.get("/{invoice_id}/download")
async def download_invoice(invoice_id: str, db: Session = Depends(get_db)):
    invoice = db.get(Invoice, invoice_id)
    if not invoice:
        raise HTTPException(status_code=404, detail="Invoice not found")

    # TEST FILE (the file you uploaded earlier). Use this while testing.
    test_path = "/mnt/data/crew_log_details.html"
    if os.path.exists(test_path):
        return FileResponse(test_path, filename=(invoice.original_filename or f"{invoice_id}.html"), media_type="text/html")

    # fallback: search storage dir if you have one configured (optional)
    storage_dir = os.getenv("INVOICE_STORAGE_DIR", "/var/www/invoices")
    if os.path.isdir(storage_dir):
        for fname in os.listdir(storage_dir):
            if fname.startswith(invoice_id):
                return FileResponse(os.path.join(storage_dir, fname), filename=invoice.original_filename or fname)
    raise HTTPException(status_code=404, detail="Stored file not found")


@router.delete("/{invoice_id}")
async def delete_invoice(invoice_id: str, db: Session = Depends(get_db)):
    invoice = db.get(Invoice, invoice_id)
    if not invoice:
        raise HTTPException(status_code=404, detail="Invoice not found")

    # delete dependents first (order matters)
    db.exec(delete(InvoiceSummary).where(InvoiceSummary.invoice_id == invoice_id))
    db.exec(delete(InvoicePage).where(InvoicePage.invoice_id == invoice_id))

    db.delete(invoice)
    db.commit()

    # optionally delete files in storage directory (best-effort)
    storage_dir = os.getenv("INVOICE_STORAGE_DIR", "/var/www/invoices")
    if os.path.isdir(storage_dir):
        for fname in os.listdir(storage_dir):
            if fname.startswith(invoice_id):
                try:
                    os.remove(os.path.join(storage_dir, fname))
                except Exception:
                    pass

    return JSONResponse({"detail": "deleted"})

@router.patch("/{invoice_id}/extraction")
async def update_extraction(invoice_id: str, payload: dict, db: Session = Depends(get_db)):
    invoice = db.get(Invoice, invoice_id)
    if not invoice:
        raise HTTPException(status_code=404, detail="Invoice not found")
    invoice.extraction_json = payload
    db.add(invoice)
    db.commit()
    db.refresh(invoice)
    return {"detail": "updated"}


@router.post("/{invoice_id}/generate-summary", response_model=GenerateSummaryResponse)
async def generate_invoice_summary(
    invoice_id: str,
    body: GenerateSummaryRequest,
    session: Session = Depends(get_db),
):
    # load invoice
    q = select(Invoice).where(Invoice.invoice_id == invoice_id)
    invoice_row = (session.exec(q)).one_or_none()
    if not invoice_row:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Invoice not found")

    # create extractor
    extractor = ExtractionService()

    # Decide: use extraction_json if present, otherwise try to get base64 image
    summary_text = None
    generation_method = "unknown"

    try:
        # Prefer structured extraction if present
        ext = invoice_row.extraction_json or None
        if isinstance(ext, str):
            # if stored as JSON string, parse it
            import json
            try:
                ext = json.loads(ext)
            except Exception:
                ext = invoice_row.extraction_json

        if ext and ( (isinstance(ext, dict) and (ext.get("key-value-pairs") or ext.get("tables") or ext.get("page-wise-data"))) or (hasattr(ext, "items") and len(ext.items())>0) ):
            summary_text, generation_method = await extractor.summarize_from_extraction(ext, prompt=body.prompt)
        else:
            # fetch first invoice page with base64_image
            q2 = select(InvoicePage).where(InvoicePage.invoice_id == invoice_id).order_by(InvoicePage.page_number)
            page = (session.exec(q2)).first()
            b64 = getattr(page, "base64_image", None) if page else None

            if b64:
                summary_text, generation_method = await extractor.generate_summary_from_base64(b64, prompt=body.prompt)
            else:
                raise HTTPException(status_code=400, detail="No extraction JSON or page image available to generate a summary")
    except HTTPException:
        raise
    except Exception as e:
        # log if you have a logger; return 500
        raise HTTPException(status_code=500, detail=f"Summary generation failed: {str(e)}")

    # At this point we have summary_text and generation_method — persist it
    try:
        word_count = len(summary_text.split()) if summary_text else 0
        summary_row = InvoiceSummary(
            invoice_id=invoice_row.invoice_id,
            summary_text=summary_text,
            generated_prompt=body.prompt,
            word_count=word_count,
            generation_method=generation_method,
        )
        session.add(summary_row)
        session.commit()
        session.refresh(summary_row)
    except Exception as e:
        # If DB insertion fails, surface an error but keep original summary_text in message if helpful
        raise HTTPException(status_code=500, detail=f"Failed to save summary: {str(e)}")

    return GenerateSummaryResponse(
        id=summary_row.id,
        invoice_id=summary_row.invoice_id,
        summary_text=summary_row.summary_text,
        generated_prompt=summary_row.generated_prompt,
        word_count=summary_row.word_count,
        generation_method=summary_row.generation_method,
    )
    


@router.get("/{invoice_id}/get-summary", response_model=GenerateSummaryResponse)
async def get_summary(
    invoice_id: str,
    db: Session = Depends(get_db)
    ):
    
    """ Get Summary from DB if present """
    
    stmt = select(Invoice).where(Invoice.invoice_id == invoice_id)
    invoice = db.exec(stmt).one_or_none()
    if not invoice:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Invoice not found")
    
    try:
        
        stmt = select(InvoiceSummary).where(InvoiceSummary.invoice_id == invoice_id)
        summary = db.exec(stmt).one_or_none()
        
    except:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Internal Server Error - Conflict Could Be Multi Result")
    
    if not summary:
        
        return JSONResponse(
            status_code=status.HTTP_200_OK,
            content = {
                "found" : False,
                "summary" : None
            }
        )
        
    if summary:
        
        return JSONResponse(
            status_code=status.HTTP_200_OK,
            content = {
                "found" : True,
                "summary" : summary.summary_text
            }
        )
        
        
@router.post("/direct-result-upload")
async def upload_invoice_direct_result(
    file: UploadFile = File(...),
):
    # Validate image
    ext = file.filename.lower()
    if not (ext.endswith(".png") or ext.endswith(".jpg") or ext.endswith(".jpeg")):
        raise HTTPException(status_code=400, detail="Only PNG/JPG invoices allowed")

    file_bytes = await file.read()

    extractor = ExtractionService()

    extraction = await extractor.process_invoice_direct(
        file_bytes=file_bytes,
        filename=file.filename,
    )

    return extraction.model_dump(by_alias=True)

# --- Mobile Endpoints ---

@router.post("/mobile/extract", response_model=InvoiceMobileExtractResponse)
async def extract_invoice_mobile(
    file: UploadFile = File(...),
    company_id: int = Form(...),
    location_id: int = Form(...),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    # Validate file type
    filename = file.filename.lower()
    if not (filename.endswith(".png") or filename.endswith(".jpg") or filename.endswith(".jpeg") or filename.endswith(".pdf")):
        raise HTTPException(status_code=400, detail="Only PNG/JPG/JPEG/PDF invoices allowed")

    file_bytes = await file.read()
    
    if not verify_access(db, current_user, company_id, location_id):
        raise HTTPException(status_code=403, detail="Unauthorized access to this company/location")

    extractor = ExtractionService()

    # Process without saving
    invoice, page_extractions, b64_images = await extractor.process_invoice(
        file_bytes=file_bytes,
        filename=file.filename,
        invoice_id=str(uuid.uuid4()) # Dummy ID
    )

    return InvoiceMobileExtractResponse(
        extraction_json=invoice.extraction_json,
        b64_images=b64_images,
        original_filename=file.filename,
        page_count=len(b64_images)
    )

@router.post("/mobile/confirm")
async def confirm_invoice_mobile(
    payload: InvoiceMobileConfirmRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    if not verify_access(db, current_user, payload.company_id, payload.location_id):
        raise HTTPException(status_code=403, detail="Unauthorized access to this company/location")

    invoice_id = str(uuid.uuid4())
    is_pdf = payload.original_filename.lower().endswith(".pdf")

    # Create Invoice record
    invoice = Invoice(
        invoice_id=invoice_id,
        title=payload.original_filename.split(".")[0],
        extension=payload.original_filename.split(".")[-1] if not is_pdf else "pdf",
        original_filename=payload.original_filename,
        file_hash=None, 
        page_count=payload.page_count,
        extraction_json=payload.extraction_json,
        ocr_result=None,
        status="uploaded",
        user_id=current_user.id,
        company_id=payload.company_id,
        location_id=payload.location_id
    )
    
    db.add(invoice)
    db.commit()
    db.refresh(invoice)

    for idx, b64_image in enumerate(payload.b64_images):
        page = InvoicePage(
            invoice_id=invoice_id,
            page_number=idx + 1,
            content="",
            base64_image=b64_image,
        )
        db.add(page)
    
    db.commit()

    return {
        "invoice_id": invoice_id,
        "message": "Invoice saved successfully from mobile",
    }

# @router.post("/direct-result-upload")
# async def upload_invoice_direct_result(
#     file: UploadFile = File(...),
#     gpt_client=Depends(get_async_openai_client),
# ):

#     import time
#     time.sleep(2)  # Simulate processing delay

#     return { "items": [ { "quantity": "1", "unit_price": "100.00", "item_name": "Front and rear brake cables", "line_total": "100.00" }, { "quantity": "2", "unit_price": "15.00", "item_name": "New set of pedal arms", "line_total": "30.00" }, { "quantity": "3", "unit_price": "5.00", "item_name": "Labor 3hrs", "line_total": "15.00" } ], "total_cost": "$154.06" }
    
    
    