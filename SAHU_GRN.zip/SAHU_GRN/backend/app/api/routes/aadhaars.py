import os
from typing import Optional
import uuid
from datetime import datetime
from fastapi import APIRouter, UploadFile, File, HTTPException, Depends, status, Form
from fastapi.responses import FileResponse, JSONResponse
from sqlmodel import Session, func, select, delete
from app.db.session import get_db
from app.db.db_models import Aadhaar, AadhaarPage, User
from app.services.extraction_service import ExtractionService
from app.core.config import settings
from app.core.auth import get_current_user, verify_access
from app.schemas.api_models import AadhaarMobileExtractResponse, AadhaarMobileConfirmRequest, PaginatedAadhaarResponse

router = APIRouter()

@router.post("/upload")
async def upload_aadhaar(
    file: UploadFile = File(...),
    company_id: int = Form(...),
    location_id: int = Form(...),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    # Validate file type
    filename = file.filename.lower()
    if not (filename.endswith(".png") or filename.endswith(".jpg") or filename.endswith(".jpeg") or filename.endswith(".pdf")):
        raise HTTPException(status_code=400, detail="Only PNG/JPG/JPEG/PDF Aadhaar cards allowed")

    file_bytes = await file.read()
    
    if not verify_access(db, current_user, company_id, location_id):
        raise HTTPException(status_code=403, detail="Unauthorized access to this company/location")

    aadhaar_id = str(uuid.uuid4())
    extractor = ExtractionService()

    aadhaar, page_extractions, b64_images = await extractor.process_aadhaar(
        file_bytes=file_bytes,
        filename=file.filename,
        aadhaar_id=aadhaar_id
    )

    aadhaar.user_id = current_user.id
    aadhaar.company_id = company_id
    aadhaar.location_id = location_id
    
    db.add(aadhaar)
    db.commit()
    db.refresh(aadhaar)

    for idx, b64_image in enumerate(b64_images):
        page = AadhaarPage(
            aadhaar_id=aadhaar_id,
            page_number=idx + 1,
            base64_image=b64_image,
        )
        db.add(page)
    
    db.commit()

    return {
        "aadhaar_id": aadhaar_id,
        "message": "Aadhaar card uploaded and processed",
        "extraction": aadhaar.extraction_json,
    }

@router.get("", response_model=PaginatedAadhaarResponse)
async def get_aadhaars(
    company_id: Optional[int] = None,
    location_id: Optional[int] = None,
    db: Session = Depends(get_db),
    page: int = 1,
    page_size: int = 25,
    search: Optional[str] = None,
    current_user: User = Depends(get_current_user),
):
    if page_size > 100: page_size = 100
    if page_size < 1: page_size = 25
    if page < 1: page = 1

    if not verify_access(db, current_user, company_id, location_id):
        raise HTTPException(status_code=403, detail="Unauthorized access to this company/location")

    from app.db.db_models import User as User_DB, Company, Location

    base_query = select(Aadhaar, User_DB.username, Company.name.label("company_name"), Location.name.label("location_name")).join(
        User_DB, Aadhaar.user_id == User_DB.id
    ).join(
        Company, Aadhaar.company_id == Company.id
    ).join(
        Location, Aadhaar.location_id == Location.id
    ).where(
        Aadhaar.company_id == company_id,
        Aadhaar.location_id == location_id
    )
    if search:
        s = f"%{search.lower()}%"
        base_query = base_query.where(
            (func.lower(Aadhaar.original_filename).like(s)) |
            (func.lower(Aadhaar.title).like(s)) |
            (func.lower(Aadhaar.aadhaar_id).like(s)) |
            (func.lower(Aadhaar.status).like(s)) |
            (func.lower(User_DB.username).like(s))
        )

    count_query = select(func.count()).select_from(Aadhaar).where(
        Aadhaar.company_id == company_id,
        Aadhaar.location_id == location_id
    )
    if search:
        s = f"%{search.lower()}%"
        count_query = count_query.join(User_DB, Aadhaar.user_id == User_DB.id).where(
            (func.lower(Aadhaar.original_filename).like(s)) |
            (func.lower(Aadhaar.title).like(s)) |
            (func.lower(Aadhaar.aadhaar_id).like(s)) |
            (func.lower(Aadhaar.status).like(s)) |
            (func.lower(User_DB.username).like(s))
        )

    total_result = db.exec(count_query).one()
    try:
        total = int(total_result)
    except:
        try: total = int(total_result[0])
        except: total = 0

    offset = (page - 1) * page_size
    results = db.exec(
        base_query.order_by(Aadhaar.created_at.desc()).offset(offset).limit(page_size)
    ).all()

    items = []
    # results is a list of tuples: (Aadhaar, username, company_name, location_name)
    for aadhaar, username, company_name, location_name in results:
        items.append({
            "aadhaar_id": aadhaar.aadhaar_id,
            "original_filename": aadhaar.original_filename,
            "title": aadhaar.title,
            "status": aadhaar.status,
            "username": username,
            "company_name": company_name,
            "location_name": location_name,
            "page_count": aadhaar.page_count,
            "created_at": aadhaar.created_at.isoformat() if aadhaar.created_at else None,
        })

    return PaginatedAadhaarResponse(
        items=items,
        total=total,
        page=page,
        page_size=page_size
    )

@router.get("/{aadhaar_id}")
async def get_aadhaar_detail(aadhaar_id: str, db: Session = Depends(get_db), current_user=Depends(get_current_user)):
    from app.db.db_models import User as User_DB, Company, Location

    result = db.exec(
        select(Aadhaar, User_DB.username, Company.name.label("company_name"), Location.name.label("location_name")).join(
            User_DB, Aadhaar.user_id == User_DB.id
        ).join(
            Company, Aadhaar.company_id == Company.id
        ).join(
            Location, Aadhaar.location_id == Location.id
        ).where(Aadhaar.aadhaar_id == aadhaar_id)
    ).one_or_none()

    if not result:
        raise HTTPException(status_code=404, detail="Aadhaar document not found")

    aadhaar, username, company_name, location_name = result

    return {
        "aadhaar_id": aadhaar.aadhaar_id,
        "title": aadhaar.title,
        "original_filename": aadhaar.original_filename,
        "status": aadhaar.status,
        "username": username,
        "company_name": company_name,
        "location_name": location_name,
        "page_count": aadhaar.page_count,
        "extraction_json": aadhaar.extraction_json,
        "created_at": aadhaar.created_at.isoformat() if aadhaar.created_at else None,
    }

@router.get("/{aadhaar_id}/pages")
async def get_aadhaar_pages(aadhaar_id: str, db: Session = Depends(get_db), current_user=Depends(get_current_user)):
    pages = db.exec(select(AadhaarPage).where(AadhaarPage.aadhaar_id == aadhaar_id).order_by(AadhaarPage.page_number)).all()
    return [
        {"page_number": p.page_number, "base64_image": p.base64_image}
        for p in pages
    ]

@router.delete("/{aadhaar_id}")
async def delete_aadhaar(aadhaar_id: str, db: Session = Depends(get_db), current_user=Depends(get_current_user)):
    aadhaar = db.get(Aadhaar, aadhaar_id)
    if not aadhaar:
        raise HTTPException(status_code=404, detail="Aadhaar not found")
    db.exec(delete(AadhaarPage).where(AadhaarPage.aadhaar_id == aadhaar_id))
    db.delete(aadhaar)
    db.commit()
    return JSONResponse({"detail": "deleted"})

@router.patch("/{aadhaar_id}/extraction")
async def update_extraction(aadhaar_id: str, payload: dict, db: Session = Depends(get_db), current_user=Depends(get_current_user)):
    aadhaar = db.get(Aadhaar, aadhaar_id)
    if not aadhaar:
        raise HTTPException(status_code=404, detail="Aadhaar not found")
    aadhaar.extraction_json = payload
    db.add(aadhaar)
    db.commit()
    return {"detail": "updated"}

# --- Mobile Endpoints ---

@router.post("/mobile/extract", response_model=AadhaarMobileExtractResponse)
async def extract_aadhaar_mobile(
    file: UploadFile = File(...),
    company_id: int = Form(...),
    location_id: int = Form(...),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    # Validate file type
    filename = file.filename.lower()
    if not (filename.endswith(".png") or filename.endswith(".jpg") or filename.endswith(".jpeg") or filename.endswith(".pdf")):
        raise HTTPException(status_code=400, detail="Only PNG/JPG/JPEG/PDF Aadhaar cards allowed")

    file_bytes = await file.read()
    
    if not verify_access(db, current_user, company_id, location_id):
        raise HTTPException(status_code=403, detail="Unauthorized access to this company/location")

    extractor = ExtractionService()

    # Process without saving
    aadhaar, page_extractions, b64_images = await extractor.process_aadhaar(
        file_bytes=file_bytes,
        filename=file.filename,
        aadhaar_id=str(uuid.uuid4()) # Dummy ID
    )

    return AadhaarMobileExtractResponse(
        extraction_json=aadhaar.extraction_json,
        b64_images=b64_images,
        original_filename=file.filename,
        page_count=len(b64_images)
    )

@router.post("/mobile/confirm")
async def confirm_aadhaar_mobile(
    payload: AadhaarMobileConfirmRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    if not verify_access(db, current_user, payload.company_id, payload.location_id):
        raise HTTPException(status_code=403, detail="Unauthorized access to this company/location")

    aadhaar_id = str(uuid.uuid4())
    is_pdf = payload.original_filename.lower().endswith(".pdf")

    # Create Aadhaar record
    aadhaar = Aadhaar(
        aadhaar_id=aadhaar_id,
        title=payload.original_filename.split(".")[0],
        extension=payload.original_filename.split(".")[-1] if not is_pdf else "pdf",
        original_filename=payload.original_filename,
        file_hash=None, # Hash not available without original bytes
        page_count=payload.page_count,
        extraction_json=payload.extraction_json,
        ocr_result=None, # Assuming we don't need full OCR result from mobile
        status="uploaded",
        user_id=current_user.id,
        company_id=payload.company_id,
        location_id=payload.location_id
    )
    
    db.add(aadhaar)
    db.commit()
    db.refresh(aadhaar)

    for idx, b64_image in enumerate(payload.b64_images):
        page = AadhaarPage(
            aadhaar_id=aadhaar_id,
            page_number=idx + 1,
            base64_image=b64_image,
        )
        db.add(page)
    
    db.commit()

    return {
        "aadhaar_id": aadhaar_id,
        "message": "Aadhaar saved successfully from mobile",
    }
