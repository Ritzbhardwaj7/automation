from datetime import timedelta
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, status, Response
from fastapi.security import OAuth2PasswordRequestForm

from app.core.auth import authenticate_user, create_access_token, Token
from app.core.config import settings
from sqlmodel import Session, select
from app.db.session import get_db
from app.db.db_models import User, Company, Location, UserAccess
from app.core.auth import get_current_user

router = APIRouter()


@router.post("/login", response_model=Token)
async def login_for_access_token(
        response: Response,
        form_data: OAuth2PasswordRequestForm = Depends()
) -> Any:
    """
    OAuth2 compatible token login, get an access token for future requests
    """
    user_authenticated = authenticate_user(form_data.username, form_data.password)
    if not user_authenticated:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": "Bearer"},
        )

    access_token_expires = timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": form_data.username}, expires_delta=access_token_expires
    )

    # Set cookie for server-side auth (secure=True in production)
    response.set_cookie(
        key="access_token",
        value=access_token,
        httponly=True,
        max_age=settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60,
        path="/"
    )

    return {
        "access_token": access_token, 
        "token_type": "bearer",
        "username": user_authenticated.username,
        "role": user_authenticated.role
    }

@router.get("/user-access")
async def get_user_access(
    current_user: User = Depends(get_current_user), 
    db: Session = Depends(get_db)
):
    if current_user.role == "admin":
        companies = db.exec(select(Company)).all()
        locations = db.exec(select(Location)).all()
        return {
            "is_admin": True,
            "companies": [c.model_dump() for c in companies],
            "locations": [l.model_dump() for l in locations]
        }
    
    # For regular users, get specific combinations
    stmt = select(Company, Location).where(
        UserAccess.user_id == current_user.id,
        UserAccess.company_id == Company.id,
        UserAccess.location_id == Location.id
    )
    results = db.exec(stmt).all()
    
    access_list = []
    for comp, loc in results:
        access_list.append({
            "company": comp.model_dump(),
            "location": loc.model_dump()
        })
        
    return {
        "is_admin": False,
        "access": access_list
    }


@router.post("/logout")
async def logout(response: Response):
    """
    Logout endpoint to clear the HTTP-only auth cookie
    """
    response.delete_cookie(
        key="access_token",
        path="/"
    )

    return {"detail": "Successfully logged out"}
